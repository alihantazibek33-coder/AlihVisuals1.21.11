package kz.alih.visuals.games.roulette;

import kz.alih.visuals.games.GameCamera;
import kz.alih.visuals.games.GameHub;
import kz.alih.visuals.games.GameNet;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Russian roulette for two. The player who invited (host) loads the single bullet, spins the cylinder, puts the
 * revolver on the table and spins it - whoever the barrel points at starts. Then the players take turns pulling the
 * trigger at their own temple until the shot comes.
 *
 * The host decides the result. To keep it honest the host sends a hash of (bullet position, cylinder position, salt)
 * before the first shot and reveals the three values at the end, so the guest can check nothing was changed.
 *
 * Messages: go = start of a round, pull = guest pulls the trigger, res = result (1 bang / 0 click),
 *           rev = reveal for the fairness check, rm = rematch.
 */
public class RouletteGame implements GameHub.Game {
    public enum Ph { INTRO, TAKE, LOAD, SPIN, PUT, TSPIN, POINT, PICK, RAISE, AWAIT, TENSION, CLICK, BANG, DONE }

    private static final Random RNG = new Random();
    public static final float TABLE_TOP = 0.95f;

    private final String opponent;
    public final boolean host;

    // ---- geometry: scene space has +X from host to guest, the table in the middle
    public Vec3d center = Vec3d.ZERO;
    public double axisX = 1, axisZ = 0;
    public float dist = 3f;
    private Vec3d myStart = Vec3d.ZERO;
    public final long sceneT0 = System.currentTimeMillis();

    // ---- round state
    public Ph ph = Ph.INTRO;
    private long t0 = System.currentTimeMillis();
    private final boolean[] fired = new boolean[12];
    public int theta;                       // final angle of the revolver on the table (degrees, 0 = barrel towards the guest)
    public boolean starterIsHost, shooterIsHost, bang;
    public Boolean loserIsHost;             // null until somebody is shot
    private int bullet, cur;
    private String salt = "", commit = "", revealInfo = "";
    private boolean pendingPull;
    private String pendingRes;
    private boolean triggerPressed;
    public boolean iWantRematch, oppWantsRematch;
    public String fairness = "";
    private boolean endScreenShown;

    // ---- visual state for the HUD / camera
    public float flash, blood, black;
    public final List<float[]> drops = new ArrayList<>();    // x y z vx vy vz life   (scene space)
    public final List<float[]> splats = new ArrayList<>();   // x y z size             (scene space)
    private long lastFrame = System.currentTimeMillis();
    private long lastBeat;

    public RouletteGame(String opponent, boolean host) {
        this.opponent = opponent;
        this.host = host;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            Vec3d me = mc.player.getPos();
            Entity o = GameHub.playerNear(opponent);
            Vec3d op = o != null ? o.getPos() : me.add(2, 0, 0);
            Vec3d h = host ? me : op, g = host ? op : me;
            double dx = g.x - h.x, dz = g.z - h.z;
            double len = Math.max(0.5, Math.sqrt(dx * dx + dz * dz));
            axisX = dx / len; axisZ = dz / len;
            dist = (float) len;
            center = new Vec3d((h.x + g.x) / 2, Math.min(h.y, g.y), (h.z + g.z) / 2);
            myStart = me;
            RSound.tableAppear(center.x, center.y + 1, center.z);
        }
        GameCamera.active = true;
    }

    // ------------------------------------------------------------------ GameHub.Game
    @Override public String opponent() { return opponent; }
    @Override public GameHub.Kind kind() { return GameHub.Kind.ROULETTE; }
    @Override public boolean locksPlayer() { return true; }
    @Override public void onClosed() { GameCamera.reset(); }

    /** called at the very start of a client tick: swallow right / left click so the trigger doesn't use items */
    @Override
    public void startTick(MinecraftClient mc) {
        while (mc.options.useKey.wasPressed()) triggerPressed = true;
        while (mc.options.attackKey.wasPressed()) triggerPressed = true;
    }

    public boolean shooterIsMe() { return shooterIsHost == host; }
    public double e() { return (System.currentTimeMillis() - t0) / 1000.0; }
    public String shooterName() { return shooterIsHost == host ? "Сен" : opponent; }
    public String starterName() { return starterIsHost == host ? "Сен" : opponent; }

    private void set(Ph p) {
        ph = p;
        t0 = System.currentTimeMillis();
        java.util.Arrays.fill(fired, false);
    }

    private boolean at(int id, double e, double when) {
        if (e >= when && !fired[id]) { fired[id] = true; return true; }
        return false;
    }

    /** scene point -> world coordinates (for sounds) */
    private double wx(double lx, double lz) { return center.x + axisX * lx - axisZ * lz; }
    private double wz(double lx, double lz) { return center.z + axisZ * lx + axisX * lz; }
    @FunctionalInterface private interface Snd { void play(double x, double y, double z); }
    private void sound(Snd s, double lx, double ly, double lz) { s.play(wx(lx, lz), center.y + ly, wz(lx, lz)); }

    // ------------------------------------------------------------------ rounds
    private void startRound() {                       // host only
        bullet = RNG.nextInt(6);
        cur = RNG.nextInt(6);
        salt = Integer.toHexString(RNG.nextInt()) + Integer.toHexString(RNG.nextInt());
        theta = RNG.nextInt(360);
        starterIsHost = Math.cos(Math.toRadians(theta)) <= 0;
        commit = hash(bullet + ":" + cur + ":" + salt);
        revealInfo = bullet + ";" + cur + ";" + salt;
        loserIsHost = null; bang = false; fairness = "";
        GameNet.send(opponent, "go", (starterIsHost ? "0" : "1") + ";" + theta + ";" + commit);
        set(Ph.TAKE);
    }

    private static String hash(String s) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 8; i++) sb.append(String.format("%02x", d[i]));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }

    private void decide() {                           // host only: the shooter pulled the trigger
        bang = cur == bullet;
        cur = (cur + 1) % 6;
        GameNet.send(opponent, "res", bang ? "1" : "0");
        applyResult(bang);
    }

    private void applyResult(boolean b) {
        bang = b;
        if (b) loserIsHost = shooterIsHost;
        set(b ? Ph.BANG : Ph.CLICK);
        pendingRes = null;
    }

    public void askRematch() {
        if (ph != Ph.DONE) return;
        iWantRematch = true;
        GameNet.send(opponent, "rm", "x");
        maybeRestart();
    }

    private void maybeRestart() {
        if (iWantRematch && oppWantsRematch) {
            iWantRematch = oppWantsRematch = false;
            endScreenShown = false;
            drops.clear(); splats.clear();
            flash = blood = black = 0f;
            loserIsHost = null; pendingPull = false; pendingRes = null;
            set(Ph.INTRO);
            if (host) startRound();
        }
    }

    @Override
    public void onMessage(String type, String data) {
        switch (type) {
            case "go" -> {
                if (host) return;
                String[] p = data.split(";");
                if (p.length < 3) return;
                try {
                    starterIsHost = "0".equals(p[0]);
                    theta = Integer.parseInt(p[1]);
                    commit = p[2];
                    loserIsHost = null; bang = false; fairness = "";
                    pendingPull = false; pendingRes = null;
                    set(Ph.TAKE);
                } catch (NumberFormatException ignored) {}
            }
            case "pull" -> { if (host) pendingPull = true; }
            case "res" -> { if (!host) pendingRes = data; }
            case "rev" -> {
                String[] p = data.split(";");
                if (host || p.length < 3) return;
                fairness = hash(p[0] + ":" + p[1] + ":" + p[2]).equals(commit) ? "✔ Әділ ойын: оқтың орны алдын ала бекітілген" : "⚠ Хост нәтижені өзгерткен болуы мүмкін!";
            }
            case "rm" -> { oppWantsRematch = true; maybeRestart(); }
            default -> {}
        }
    }

    // ------------------------------------------------------------------ main logic (20 times a second)
    @Override
    public void tick(MinecraftClient mc) {
        if (mc.player == null) return;
        // sitting still: leaving the chair ends the game
        if (mc.player.getPos().squaredDistanceTo(myStart) > 4.0 && ph != Ph.DONE) {
            mc.player.sendMessage(Text.literal("[Games] Орындықтан тұрдың - ойын тоқтады"), false);
            GameHub.closeActive(true);
            return;
        }
        double e = e();
        boolean trig = triggerPressed;
        triggerPressed = false;
        float hx = -dist / 2f, gx = dist / 2f;

        switch (ph) {
            case INTRO -> { if (host && e >= 2.4) startRound(); }
            case TAKE -> {
                if (at(0, e, 0.35)) sound(RSound::pickUp, hx + 0.4, 1.1, 0);
                if (e >= 1.0) set(Ph.LOAD);
            }
            case LOAD -> {
                if (at(0, e, 0.3)) sound(RSound::open, hx + 0.4, 1.1, 0);
                if (at(1, e, 0.9)) sound(RSound::insert, hx + 0.4, 1.1, 0);
                if (at(2, e, 1.6)) sound(RSound::close, hx + 0.4, 1.1, 0);
                if (e >= 2.1) set(Ph.SPIN);
            }
            case SPIN -> {
                for (int i = 0; i < 12; i++) if (at(i, e, 0.1 + i * 0.15)) sound((x, y, z) -> RSound.ratchet(x, y, z, 1.2f + (float) RNG.nextDouble() * 0.5f), hx + 0.4, 1.1, 0);
                if (e >= 2.0) set(Ph.PUT);
            }
            case PUT -> {
                if (at(0, e, 0.65)) sound(RSound::putDown, 0, TABLE_TOP, 0);
                if (e >= 0.9) set(Ph.TSPIN);
            }
            case TSPIN -> {
                for (int i = 0; i < 11; i++) if (at(i, e, 0.2 + i * i * 0.026)) sound((x, y, z) -> RSound.ratchet(x, y, z, 0.9f), 0, TABLE_TOP, 0);
                if (e >= 3.6) { shooterIsHost = starterIsHost; set(Ph.POINT); }
            }
            case POINT -> { if (e >= 1.8) set(Ph.PICK); }
            case PICK -> {
                if (at(0, e, 0.2)) sound(RSound::pickUp, shooterIsHost ? hx : gx, 1.0, 0);
                if (e >= 0.8) set(Ph.RAISE);
            }
            case RAISE -> {
                if (at(0, e, 0.4)) sound(RSound::cock, shooterIsHost ? hx : gx, 1.5, 0);
                if (e >= 1.3) set(Ph.AWAIT);
            }
            case AWAIT -> {
                if (e - lastBeatSec() > 1.1) { lastBeat = System.currentTimeMillis(); sound(RSound::heartbeat, shooterIsHost ? hx : gx, 1.5, 0); }
                if (shooterIsMe() && trig) {
                    if (host) decide();
                    else { GameNet.send(opponent, "pull", "x"); set(Ph.TENSION); }
                } else if (host && !shooterIsMe() && pendingPull) { pendingPull = false; decide(); }
                else if (!host && pendingRes != null) applyResult("1".equals(pendingRes));
            }
            case TENSION -> { if (!host && pendingRes != null && e >= 0.5) applyResult("1".equals(pendingRes)); }
            case CLICK -> {
                if (at(0, e, 0.02)) sound(RSound::dryClick, shooterIsHost ? hx : gx, 1.5, 0);
                if (at(1, e, 0.8)) sound(RSound::putDown, 0, TABLE_TOP, 0);
                if (e >= 1.4) { shooterIsHost = !shooterIsHost; set(Ph.PICK); }
            }
            case BANG -> {
                double sx = loserIsHost != null && loserIsHost ? hx : gx;
                if (at(0, e, 0.02)) { sound(RSound::shot, sx, 1.5, 0); spawnBlood(sx); }
                if (at(1, e, 0.12)) sound(RSound::hurt, sx, 1.5, 0);
                if (at(2, e, 1.0)) sound(RSound::bodyFall, sx, 1.0, 0);
                if (e >= 3.6) {
                    set(Ph.DONE);
                    if (host) GameNet.send(opponent, "rev", revealInfo);
                }
            }
            case DONE -> {
                if (!endScreenShown && mc.currentScreen == null) {
                    endScreenShown = true;
                    mc.setScreen(new RouletteEndScreen(this));
                }
            }
        }
    }

    private double lastBeatSec() { return (lastBeat - t0) / 1000.0; }

    // ------------------------------------------------------------------ per frame: blood physics + camera
    public void frame(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.05f, (now - lastFrame) / 1000f);
        lastFrame = now;
        double e = e();
        // drops
        for (int i = drops.size() - 1; i >= 0; i--) {
            float[] d = drops.get(i);
            d[4] -= 9.8f * dt;
            d[0] += d[3] * dt; d[1] += d[4] * dt; d[2] += d[5] * dt;
            boolean onTable = Math.abs(d[0]) < Math.min(0.75f, dist / 2f - 0.45f) && Math.abs(d[2]) < 0.45f;
            if (onTable && d[1] <= TABLE_TOP) { if (splats.size() < 90) splats.add(new float[]{d[0], TABLE_TOP + 0.004f, d[2], 0.015f + (float) RNG.nextDouble() * 0.03f}); drops.remove(i); }
            else if (d[1] <= 0.01f) { if (splats.size() < 90) splats.add(new float[]{d[0], 0.012f, d[2], 0.02f + (float) RNG.nextDouble() * 0.05f}); drops.remove(i); }
            else if ((d[6] -= dt) < 0) drops.remove(i);
        }

        // camera + overlays
        flash = 0f; blood = 0f; black = 0f;
        float yaw = 0, pitch = 0, fov = 1f; double dy = 0;
        boolean meShooter = shooterIsMe();
        switch (ph) {
            case INTRO, TAKE -> { }
            case LOAD, SPIN -> { if (host) pitch = 14f * ease((float) Math.min(1, e / 0.6)); }
            case PICK -> { if (meShooter) pitch = 6f * ease((float) Math.min(1, e / 0.8)); }
            case RAISE, AWAIT, TENSION -> {
                if (meShooter) {
                    float tens = ph == Ph.RAISE ? (float) (e / 1.3) : 1f;
                    float amp = 0.25f + 0.35f * Math.min(1f, (float) e / 4f);
                    yaw = (float) Math.sin(now / 90.0) * amp * tens; pitch = 6f + (float) Math.cos(now / 110.0) * amp * tens;
                    fov = 1f - 0.14f * ease(Math.min(1f, tens));
                }
            }
            case CLICK -> { if (meShooter) { pitch = 6f * (1f - ease((float) Math.min(1, e / 0.8))); fov = 1f - 0.14f * (1f - ease((float) Math.min(1, e / 0.6))); } }
            case BANG, DONE -> {
                float fe = (float) (ph == Ph.DONE ? 9 : e);
                flash = Math.max(0f, 0.85f - fe * 3.4f);
                boolean iLost = loserIsHost != null && loserIsHost == host;
                if (iLost) {
                    float shake = Math.max(0f, 1f - fe * 2.5f) * 5f;
                    float fall = ease(Math.min(1f, Math.max(0f, (fe - 0.35f) / 1.1f)));
                    yaw = (float) Math.sin(now / 35.0) * shake + 14f * fall;
                    pitch = 6f + (float) Math.cos(now / 41.0) * shake + 70f * fall;
                    dy = -0.75 * fall;
                    fov = 1f - 0.1f * fall;
                    blood = Math.min(1f, Math.max(0f, (fe - 0.15f) / 0.8f)) * 0.75f;
                    black = Math.min(1f, Math.max(0f, (fe - 2.0f) / 1.4f)) * 0.92f;
                } else {
                    float shake = Math.max(0f, 1f - fe * 3f) * 2.2f;
                    pitch = (float) Math.cos(now / 40.0) * shake; yaw = (float) Math.sin(now / 47.0) * shake;
                }
            }
            default -> { }
        }
        GameCamera.active = true;
        GameCamera.yaw = yaw; GameCamera.pitch = pitch; GameCamera.fovMul = fov;
        GameCamera.dx = 0; GameCamera.dy = dy; GameCamera.dz = 0;
    }

    private static float ease(float t) { t = MathHelper.clamp(t, 0f, 1f); return t * t * (3f - 2f * t); }

    private void spawnBlood(double sx) {
        float s = (float) sx;
        float dirSign = s < 0 ? 1f : -1f;                   // the head is thrown away from the gun side (-z)
        for (int i = 0; i < 46; i++) {
            float sp = 0.6f + (float) RNG.nextDouble() * 2.2f;
            drops.add(new float[]{s + (float) RNG.nextGaussian() * 0.03f, 1.62f + (float) RNG.nextGaussian() * 0.04f, 0.12f,
                    (float) RNG.nextGaussian() * 0.7f + dirSign * 0.3f * (float) RNG.nextDouble(),
                    0.3f + (float) RNG.nextDouble() * 1.9f, -sp, 3f});
        }
    }
}
