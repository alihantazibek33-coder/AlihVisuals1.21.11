package kz.alih.visuals.games;

import kz.alih.visuals.AlihMenu;
import kz.alih.visuals.Gfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.List;

/** "Ойындар": pick a game, type the nick of a player who also uses AlihVisuals, send the invite. */
public class GamesScreen extends Screen {
    private static String lastNick = "";
    private TextFieldWidget field;
    private int px, py, pw, ph, cardH = 64;
    private List<String> chips = List.of();
    private long lastChips;

    public GamesScreen() { super(Text.literal("Games")); }

    @Override
    protected void init() {
        layout();
        field = new TextFieldWidget(textRenderer, px + 10, py + 46, pw - 20, 18, Text.literal("Nick"));
        field.setMaxLength(16);
        field.setText(lastNick);
        field.setChangedListener(s -> lastNick = s);
        addSelectableChild(field);
        setInitialFocus(field);
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void close() { client.setScreen(new AlihMenu()); }

    private void layout() {
        pw = Math.min(width - 8, 400);
        ph = Math.min(height - 8, 290);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
    }

    private int cardY(int i) { return py + 104 + i * (cardH + 6); }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) { c.fill(0, 0, width, height, 0xB0090B10); }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        layout();
        long now = System.currentTimeMillis();
        if (now - lastChips > 1500) { chips = GameHub.clientPlayers(); lastChips = now; }

        GUi.panel(c, px, py, pw, ph);
        c.drawCenteredTextWithShadow(textRenderer, "Ойындар", px + pw / 2, py + 10, GUi.CYAN);
        boolean bh = GUi.in(mx, my, px + 8, py + 6, 62, 16);
        GUi.button(c, textRenderer, "‹ Артқа", px + 8, py + 6, 62, 16, bh, false);

        c.drawTextWithShadow(textRenderer, "Ойыншы ніксі (ол да осы клиентті қолдануы керек)", px + 10, py + 32, 0xFFA0A7B6);
        field.setX(px + 10); field.setY(py + 46); field.setWidth(pw - 20);
        field.render(c, mx, my, delta);

        // quick picks: online players who use the client
        int cx = px + 10, cy = py + 70;
        if (chips.isEmpty()) {
            c.drawTextWithShadow(textRenderer, "Клиент қолданатын ойыншы көрінбейді", cx, cy + 3, 0xFF5E6575);
        } else {
            for (String n : chips) {
                int w = textRenderer.getWidth(n) + 12;
                if (cx + w > px + pw - 10) break;
                boolean h = GUi.in(mx, my, cx, cy, w, 14);
                Gfx.rrect(c, cx, cy, w, 14, 6, h ? 0xFF343946 : 0xFF2A2E38);
                c.drawTextWithShadow(textRenderer, n, cx + 6, cy + 3, 0xFFB8BFCC);
                cx += w + 4;
            }
        }

        // game cards
        GameHub.Kind[] kinds = GameHub.Kind.values();
        for (int i = 0; i < kinds.length; i++) {
            int y = cardY(i), x = px + 10, w = pw - 20;
            Gfx.rrect(c, x, y, w, cardH, 8, 0xFF2C313C);
            Gfx.rrect(c, x + 1, y + 1, w - 2, cardH - 2, 7, 0xFF23262E);
            icon(c, kinds[i], x + 8, y + 8, 48);
            c.drawTextWithShadow(textRenderer, kinds[i].title, x + 66, y + 10, GUi.CYAN);
            String d1 = kinds[i] == GameHub.Kind.CHESS ? "Екі адам онлайн шахмат ойнайды." : "Үстел, 2 орындық, 1 оқ. Бір-біріңе қарап ойнайсыңдар.";
            String d2 = kinds[i] == GameHub.Kind.CHESS ? "Кез келген қашықтықта." : "Екеуің ≤ 5 блок қашықтықта тұру керек.";
            c.drawTextWithShadow(textRenderer, d1, x + 66, y + 24, 0xFF8A90A0);
            c.drawTextWithShadow(textRenderer, d2, x + 66, y + 36, 0xFF8A90A0);
            int bx = x + w - 96, by = y + cardH - 22;
            boolean wait = GameHub.hasOutgoing();
            GUi.button(c, textRenderer, wait ? "Күтілуде..." : "Шақыру", bx, by, 88, 16, GUi.in(mx, my, bx, by, 88, 16), !wait);
        }
        if (GameHub.hasOutgoing()) {
            int bx = px + pw - 98, by = py + 6;
            GUi.button(c, textRenderer, "Бас тарту", bx, by, 88, 16, GUi.in(mx, my, bx, by, 88, 16), false);
        } else if (GameHub.active() instanceof kz.alih.visuals.games.chess.ChessGame) {
            int bx = px + pw - 128, by = py + 6;
            GUi.button(c, textRenderer, "Шахматқа оралу", bx, by, 118, 16, GUi.in(mx, my, bx, by, 118, 16), true);
        }
        String st = GameHub.status();
        if (!st.isEmpty()) c.drawCenteredTextWithShadow(textRenderer, st, px + pw / 2, py + ph - 14, 0xFFFFC66B);
    }

    private void icon(DrawContext c, GameHub.Kind k, int x, int y, int s) {
        Gfx.rrect(c, x, y, s, s, 8, 0xFF1A1D24);
        if (k == GameHub.Kind.CHESS) {
            int q = s / 4;
            for (int r = 0; r < 4; r++) for (int f = 0; f < 4; f++)
                c.fill(x + f * q, y + r * q, x + f * q + q, y + r * q + q, ((r + f) & 1) == 0 ? 0xFFE8D8B0 : 0xFF7A5A3A);
            GUi.bigText(c, textRenderer, "♞", x + s / 2f, y + s / 2f - 13, 2.6f, 0xFF15171C);
        } else {
            float cx = x + s / 2f, cy = y + s / 2f;
            Gfx.circle(c, cx, cy, s * 0.42f, 0xFF8A93A6);
            Gfx.circle(c, cx, cy, s * 0.36f, 0xFF4A5060);
            for (int i = 0; i < 6; i++) {
                double a = Math.PI * 2 * i / 6 + Math.PI / 6;
                Gfx.circle(c, cx + (float) Math.cos(a) * s * 0.22f, cy + (float) Math.sin(a) * s * 0.22f, s * 0.075f, i == 0 ? 0xFFC9A64B : 0xFF15171C);
            }
            Gfx.circle(c, cx, cy, s * 0.05f, 0xFF15171C);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            if (GUi.in(mx, my, px + 8, py + 6, 62, 16)) { close(); return true; }
            if (GameHub.hasOutgoing() && GUi.in(mx, my, px + pw - 98, py + 6, 88, 16)) { GameHub.cancelInvite(); return true; }
            if (!GameHub.hasOutgoing() && GameHub.active() instanceof kz.alih.visuals.games.chess.ChessGame cg && GUi.in(mx, my, px + pw - 128, py + 6, 118, 16)) {
                client.setScreen(new kz.alih.visuals.games.chess.ChessScreen(cg));
                return true;
            }
            int cx = px + 10, cy = py + 70;
            for (String n : chips) {
                int w = textRenderer.getWidth(n) + 12;
                if (cx + w > px + pw - 10) break;
                if (GUi.in(mx, my, cx, cy, w, 14)) { field.setText(n); return true; }
                cx += w + 4;
            }
            GameHub.Kind[] kinds = GameHub.Kind.values();
            for (int i = 0; i < kinds.length; i++) {
                int x = px + 10, w = pw - 20, bx = x + w - 96, by = cardY(i) + cardH - 22;
                if (GUi.in(mx, my, bx, by, 88, 16) && !GameHub.hasOutgoing()) {
                    GameHub.invite(kinds[i], field.getText().trim());
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
