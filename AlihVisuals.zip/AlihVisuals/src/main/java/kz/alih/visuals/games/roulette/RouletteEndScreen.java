package kz.alih.visuals.games.roulette;

import kz.alih.visuals.games.GUi;
import kz.alih.visuals.games.GameHub;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** shown when the roulette is over: result + rematch / exit */
public class RouletteEndScreen extends Screen {
    private final RouletteGame g;
    private int px, py, pw = 260, ph = 112;

    public RouletteEndScreen(RouletteGame g) { super(Text.literal("Roulette")); this.g = g; }

    @Override public boolean shouldPause() { return false; }
    @Override public void renderBackground(DrawContext c, int mx, int my, float delta) { }   // keep the scene visible
    @Override public void close() { GameHub.closeActive(true); super.close(); }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        if (GameHub.active() != g) { if (client != null) client.setScreen(null); return; }
        if (g.ph != RouletteGame.Ph.DONE) { if (client != null) client.setScreen(null); return; }   // rematch started
        px = (width - pw) / 2; py = height - ph - 20;
        GUi.panel(c, px, py, pw, ph);
        boolean iLost = g.loserIsHost != null && g.loserIsHost == g.host;
        c.drawCenteredTextWithShadow(textRenderer, iLost ? "Сен ұттырдың" : "Сен жеңдің!", px + pw / 2, py + 10, iLost ? 0xFFFF6B6B : 0xFF56E07A);
        c.drawCenteredTextWithShadow(textRenderer, "Қарсылас: " + g.opponent(), px + pw / 2, py + 24, 0xFFB8BFCC);
        if (!g.fairness.isEmpty()) c.drawCenteredTextWithShadow(textRenderer, textRenderer.trimToWidth(g.fairness, pw - 12), px + pw / 2, py + 40, g.fairness.startsWith("✔") ? 0xFF56E07A : 0xFFFFC66B);
        String rt = g.iWantRematch ? "Реванш күтілуде..." : (g.oppWantsRematch ? "Реванш қабылдау" : "Реванш");
        GUi.button(c, textRenderer, rt, px + 12, py + ph - 30, 112, 18, GUi.in(mx, my, px + 12, py + ph - 30, 112, 18), g.oppWantsRematch && !g.iWantRematch);
        GUi.button(c, textRenderer, "Шығу", px + pw - 124, py + ph - 30, 112, 18, GUi.in(mx, my, px + pw - 124, py + ph - 30, 112, 18), false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            if (GUi.in(mx, my, px + 12, py + ph - 30, 112, 18)) { if (!g.iWantRematch) g.askRematch(); return true; }
            if (GUi.in(mx, my, px + pw - 124, py + ph - 30, 112, 18)) { close(); return true; }
        }
        return super.mouseClicked(mx, my, button);
    }
}
