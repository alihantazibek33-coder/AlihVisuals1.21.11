package kz.alih.visuals;

import kz.alih.visuals.mixin.OverlayTextureAccessor;
import kz.alih.visuals.mixin.SimpleOptionAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

public class AlihVisualsClient implements ClientModInitializer {
    public static KeyBinding MENU_KEY, FREELOOK_KEY, FREECAM_KEY, ZOOM_KEY, PICK_KEY;

    private static final java.util.Set<PlayerEntity> attacked = new java.util.HashSet<>();
    private static long lastEzTime;
    private static Double savedGamma;
    private static boolean hitApplied = false;
    private static float hitHue = -1f;
    private static Perspective prevPerspective = Perspective.FIRST_PERSON;

    @Override
    public void onInitializeClient() {
        Modules.load();
        AlihUsers.init();
        kz.alih.visuals.cosmetics.CosmeticsState.get().init();
        kz.alih.visuals.cosmetics.CosmeticsFeature.register();
        MENU_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.alihvisuals.menu",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_0, "category.alihvisuals"));
        FREELOOK_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.alihvisuals.freelook",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_ALT, "category.alihvisuals"));
        FREECAM_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.alihvisuals.freecam",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F7, "category.alihvisuals"));
        ZOOM_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.alihvisuals.zoom",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.alihvisuals"));
        PICK_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.alihvisuals.pick",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "category.alihvisuals"));
        kz.alih.visuals.music.MusicPlayer.init();
        ClientTickEvents.START_CLIENT_TICK.register(this::startTick);
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> !Commands.handle(msg));
        HudRenderCallback.EVENT.register(Hud::render);
        kz.alih.visuals.games.GameNet.init();
        HudRenderCallback.EVENT.register(kz.alih.visuals.games.roulette.RouletteHud::render);
        WorldRender.register();

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient && entity instanceof PlayerEntity friend && Friends.is(friend.getUuid())) return ActionResult.FAIL;
            if (world.isClient && entity instanceof LivingEntity le) { Hud.setTarget(entity); WorldRender.spawnHit(le); TargetEsp.onAttack(entity); }
            if (world.isClient && entity instanceof PlayerEntity pe) attacked.add(pe);
            return ActionResult.PASS;
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> {
            restoreGamma(mc);
            Zoom.restore(mc);
            Modules.save();
        });
    }

    private void startTick(MinecraftClient mc) {
        while (FREECAM_KEY.wasPressed()) {
            if (mc.player != null && mc.currentScreen == null) Modules.FREECAM.enabled = !Modules.FREECAM.enabled;
        }
        kz.alih.visuals.games.GameHub.startTick(mc);
        Freecam.tick(mc);
        Zoom.keyDown = ZOOM_KEY.isPressed();
        Automation.tool(mc);
    }

    // ---------- Block Pick: H in creative = take the block you look at (same as middle click) ----------
    private static void blockPick(MinecraftClient mc) {
        while (PICK_KEY.wasPressed()) {
            if (Modules.BLOCKPICK.enabled && mc.player != null && mc.currentScreen == null && !Freecam.active
                    && mc.player.isCreative() && mc.crosshairTarget instanceof BlockHitResult hit
                    && hit.getType() == HitResult.Type.BLOCK) {
                KeyBinding.onKeyPressed(KeyBindingHelper.getBoundKeyOf(mc.options.pickItemKey));
            }
        }
    }

    private void tick(MinecraftClient mc) {
        while (MENU_KEY.wasPressed()) {
            if (mc.currentScreen == null && mc.player != null) mc.setScreen(new AlihMenu());
        }
        fullbright(mc);
        autoEz(mc);
        Ambience.tick(mc);
        hitColor(mc);
        freelook(mc);
        blockPick(mc);
        Automation.sprint(mc);
        Automation.eat(mc);
        DeathMarker.tick(mc);
        TargetEsp.tick(mc);
        kz.alih.visuals.games.GameHub.tick(mc);
        WorldRender.tick(mc);
    }

    // ---------- AutoEzz: player you hit recently died -> send "ezz" in chat ----------
    private static void autoEz(MinecraftClient mc) {
        if (attacked.isEmpty()) return;
        boolean kill = false;
        for (java.util.Iterator<PlayerEntity> it = attacked.iterator(); it.hasNext(); ) {
            PlayerEntity t = it.next();
            if (t.isDead() || t.getHealth() <= 0f) { kill = true; it.remove(); }
            else if (t.isRemoved()) it.remove();   // left / unloaded without dying
        }
        if (!kill || !Modules.AUTOEZ.enabled || mc.player == null || mc.getNetworkHandler() == null) return;
        long now = System.currentTimeMillis();
        if (now - lastEzTime < 1500) return;
        lastEzTime = now;
        mc.getNetworkHandler().sendChatMessage("ezz");
    }

    // ---------- Fulbright: gamma way above the vanilla slider limit ----------
    @SuppressWarnings("unchecked")
    private static void fullbright(MinecraftClient mc) {
        SimpleOption<Double> g = mc.options.getGamma();
        if (Modules.FULLBRIGHT.enabled) {
            if (savedGamma == null) savedGamma = g.getValue();
            ((SimpleOptionAccessor<Double>) (Object) g).alih$setRaw(16.0);
        } else {
            restoreGamma(mc);
        }
    }

    @SuppressWarnings("unchecked")
    private static void restoreGamma(MinecraftClient mc) {
        if (savedGamma != null) {
            ((SimpleOptionAccessor<Double>) (Object) mc.options.getGamma()).alih$setRaw(savedGamma);
            savedGamma = null;
        }
    }

    // ---------- HitColor: replaces the red "hurt" overlay colour ----------
    private static void hitColor(MinecraftClient mc) {
        if (mc.gameRenderer == null) return;
        boolean want = Modules.HITCOLOR.enabled;
        float hue = Modules.HITCOLOR.value;
        if (want && (!hitApplied || hue != hitHue)) {
            setHurtColor(mc, Colors.argb(200, Modules.HITCOLOR.rgb()));
            hitApplied = true;
            hitHue = hue;
        } else if (!want && hitApplied) {
            setHurtColor(mc, Colors.argb(178, 0xFF0000)); // vanilla red
            hitApplied = false;
        }
    }

    private static void setHurtColor(MinecraftClient mc, int argb) {
        OverlayTexture ot = mc.gameRenderer.getOverlayTexture();
        NativeImageBackedTexture tex = ((OverlayTextureAccessor) (Object) ot).alih$getTexture();
        NativeImage img = tex.getImage();
        if (img == null) return;
        for (int y = 0; y < 8; y++)
            for (int x = 0; x < 16; x++)
                img.setColorArgb(x, y, argb);
        tex.upload();
    }

    // ---------- Freelook: hold key, camera turns independently ----------
    private static void freelook(MinecraftClient mc) {
        boolean act = Modules.FREELOOK.enabled && mc.player != null && mc.currentScreen == null
                && !Freecam.active && FREELOOK_KEY.isPressed();
        if (act && !Freelook.active) {
            Freelook.yaw = mc.player.getYaw();
            Freelook.pitch = mc.player.getPitch();
            prevPerspective = mc.options.getPerspective();
            // "Third Person" view mode jumps out of first person; "First Person" keeps the eyes where they are
            if (Modules.FREELOOK.mode == 0 && prevPerspective.isFirstPerson())
                mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        } else if (!act && Freelook.active) {
            mc.options.setPerspective(prevPerspective);
        }
        Freelook.active = act;
    }
}
