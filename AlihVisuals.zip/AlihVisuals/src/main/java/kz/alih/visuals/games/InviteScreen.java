package kz.alih.visuals.games;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** "X invited you to ..." - accept / decline */
public class InviteScreen extends Screen {
    private int px, py, pw = 240, ph = 92;

    public InviteScreen() { super(Text.literal("Invite")); }

    @Override public boolean shouldPause() { return false; }
    @Override public void close() { GameHub.declineIncoming(); super.close(); }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        if (GameHub.incomingFrom() == null) { if (client != null) client.setScreen(null); return; }
        px = (width - pw) / 2; py = (height - ph) / 2;
        GUi.panel(c, px, py, pw, ph);
        c.drawCenteredTextWithShadow(textRenderer, "Ойынға шақыру", px + pw / 2, py + 10, GUi.CYAN);
        c.drawCenteredTextWithShadow(textRenderer, GameHub.incomingFrom() + " сені", px + pw / 2, py + 28, 0xFFE6E9EF);
        c.drawCenteredTextWithShadow(textRenderer, "«" + GameHub.incomingKind().title + "» ойынына шақырды", px + pw / 2, py + 40, 0xFFE6E9EF);
        GUi.button(c, textRenderer, "Қабылдау", px + 12, py + ph - 28, 100, 18, GUi.in(mx, my, px + 12, py + ph - 28, 100, 18), true);
        GUi.button(c, textRenderer, "Бас тарту", px + pw - 112, py + ph - 28, 100, 18, GUi.in(mx, my, px + pw - 112, py + ph - 28, 100, 18), false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            if (GUi.in(mx, my, px + 12, py + ph - 28, 100, 18)) {
                GameHub.acceptIncoming();
                if (client != null && client.currentScreen == this) client.setScreen(null);
                return true;
            }
            if (GUi.in(mx, my, px + pw - 112, py + ph - 28, 100, 18)) { close(); return true; }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ENTER) { GameHub.acceptIncoming(); if (client != null) client.setScreen(null); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
