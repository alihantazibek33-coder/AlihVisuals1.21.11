package kz.alih.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * TargetEsp - effect around the player / mob you aim at or hit (Ghosts, Ring, Square, Orbit).
 *
 * Original idea, behaviour and parameters: MaksaiTargetEsp by maksaidev (used and adapted with the author's
 * permission, see LICENSE_TargetEsp). Adapted for AlihVisuals by Alih: drawn with the mod's own vertex-colour
 * glow instead of textures, settings live in the AlihVisuals module panel.
 */
public final class TargetEsp {
    private TargetEsp() {}

    // ---------------------------------------------------------------- settings access
    private static final int S_SPEED = 0, S_MEMORY = 1, S_GHOST_SIZE = 2, S_GHOST_COUNT = 3, S_SQUARE = 4,
            S_ORBIT_COUNT = 5, S_ORBIT_LAYERS = 6, S_ORBIT_SPACING = 7, S_ORBIT_DIST = 8, S_ORBIT_SIZE = 9;
    private static final int T_HIT = 0, T_PLAYERS = 1, T_MOBS = 2, T_SPIN = 3;
    private static final int C_SHAPE = 0, C_COLOR = 1;

    private static float set(int i) { return Modules.TARGETESP.extras.get(i).value; }
    private static boolean tog(int i) { return Modules.TARGETESP.toggles.get(i).value; }
    private static int cho(int i) { return Modules.TARGETESP.choices.get(i).sel; }

    // ---------------------------------------------------------------- constants
    private static final int[][] COLORS = {{95, 65, 240}, {240, 70, 70}, {80, 220, 120}, {80, 170, 250}, {240, 240, 240}};
    private static final float HIT_R = 255f, HIT_G = 50f, HIT_B = 50f;
    private static final double HIT_SPEED_MULT = 3.0, HIT_DURATION = 0.8, HIT_RAMP_SHARE = 0.15;
    private static final double MAX_DISTANCE_SQUARED = 10000.0;
    private static final int GHOST_PARTICLES = 15;
    private static final double GHOST_SWEEP_RAD = Math.toRadians(50.0);
    private static final Vec3d UP = new Vec3d(0, 1, 0), RIGHT = new Vec3d(1, 0, 0);
    private static final Vec3d[] GHOST_AXES = {
            new Vec3d(1, 1, 1).normalize(), new Vec3d(-1, 1, -1).normalize(), new Vec3d(1, -1, 1).normalize(),
            new Vec3d(-1, -1, 1).normalize(), new Vec3d(1, 1, -1).normalize(), new Vec3d(-1, -1, -1).normalize()};
    private static final int[][] CUBE_FACES = {{0, 1, 3, 2}, {4, 6, 7, 5}, {0, 4, 5, 1}, {2, 3, 7, 6}, {0, 2, 6, 4}, {1, 5, 7, 3}};

    // ---------------------------------------------------------------- target tracking (aim / hit memory)
    private static LivingEntity currentTarget;
    private static long clearAtMs;
    private static boolean waitingToClear;

    private static long memoryMs() { return Math.round(set(S_MEMORY) * 1000f); }

    /** an NPC-like entity: invisible "player" with no armour (tab-list fakes on servers) */
    private static boolean isNpcLike(LivingEntity e) {
        if (!(e instanceof PlayerEntity p)) return false;
        if (!p.isInvisible()) return false;
        for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET})
            if (!p.getEquippedStack(s).isEmpty()) return false;
        return true;
    }

    private static void remember(LivingEntity e) {
        currentTarget = e;
        waitingToClear = true;
        clearAtMs = System.currentTimeMillis() + memoryMs();
    }

    /** called when the player attacks something */
    public static void onAttack(Entity entity) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        if (entity instanceof LivingEntity le && entity != mc.player && !isNpcLike(le)) remember(le);
    }

    /** client tick: aiming at something refreshes the memory, after the memory time it is forgotten */
    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || !Modules.TARGETESP.enabled) { clearTarget(); return; }
        boolean aiming = false;
        HitResult hr = mc.crosshairTarget;
        if (hr instanceof EntityHitResult ehr && hr.getType() == HitResult.Type.ENTITY
                && ehr.getEntity() instanceof LivingEntity le && le != mc.player && !isNpcLike(le)) {
            remember(le);
            aiming = true;
        }
        if (!aiming && waitingToClear && System.currentTimeMillis() >= clearAtMs) {
            currentTarget = null;
            waitingToClear = false;
        }
    }

    private static void clearTarget() { currentTarget = null; waitingToClear = false; }

    // ---------------------------------------------------------------- render state
    private static int lastTargetId = -1;
    private static long alphaStartMs;
    private static float rotation, phase;
    private static int prevHurt;
    private static long hitAtMs = -1, lastFrameMs;

    public static void reset() {
        lastTargetId = -1;
        lastFrameMs = 0;
        hitAtMs = -1;
        prevHurt = 0;
    }

    private static boolean isValid(MinecraftClient mc, LivingEntity e) {
        if (e == null || e == mc.player || !e.isAlive()) return false;
        if (e.getWidth() <= 0f || e.getHeight() <= 0f) return false;
        if (e.squaredDistanceTo(mc.player) > MAX_DISTANCE_SQUARED) return false;
        if (isNpcLike(e)) return false;
        return e instanceof PlayerEntity ? tog(T_PLAYERS) : tog(T_MOBS);
    }

    private static LivingEntity pickTarget(MinecraftClient mc) {
        LivingEntity t = currentTarget;
        if (isValid(mc, t)) return t;
        if (mc.targetedEntity instanceof LivingEntity le && isValid(mc, le)) return le;
        return null;
    }

    // ---------------------------------------------------------------- main
    public static void render(VertexConsumer vc, Matrix4f m, Vec3d cam, Camera camera, float td) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) { reset(); return; }
        LivingEntity e = pickTarget(mc);
        if (e == null) { reset(); return; }

        long now = System.currentTimeMillis();
        if (e.getId() != lastTargetId) {
            lastTargetId = e.getId();
            alphaStartMs = now;          // fade in from 0
            rotation = 0f; phase = 0f; prevHurt = 0; hitAtMs = -1;
        }
        float alpha = MathHelper.clamp((now - alphaStartMs) / 500f, 0f, 1f);

        double dt = lastFrameMs > 0 ? Math.min((now - lastFrameMs) / 1000.0, 0.1) : 0.0;
        lastFrameMs = now;

        // hit effect: detect the moment the target gets hurt -> short speed boost + red tint
        boolean hitFx = tog(T_HIT);
        if (hitFx && e.hurtTime >= 9 && prevHurt < 9) hitAtMs = now;
        prevHurt = e.hurtTime;
        double speedMul = 1.0;
        if (hitFx && hitAtMs > 0) {
            double t = (now - hitAtMs) / 1000.0;
            if (t <= HIT_DURATION) {
                double u = t / HIT_DURATION;
                double ramp = u < HIT_RAMP_SHARE ? smooth(u / HIT_RAMP_SHARE) : 1.0 - smooth((u - HIT_RAMP_SHARE) / (1.0 - HIT_RAMP_SHARE));
                speedMul = 1.0 + (HIT_SPEED_MULT - 1.0) * ramp;
            }
        }
        float speed = set(S_SPEED);
        rotation = (float) ((rotation + dt * speed * speedMul * 50.0) % 360.0);
        phase += (float) (dt * speed * speedMul * 2.5);

        int[] col = COLORS[Math.max(0, Math.min(COLORS.length - 1, cho(C_COLOR)))];
        float r = col[0], g = col[1], b = col[2];
        if (hitFx && e.hurtTime > 0) {
            float k = e.hurtTime / 10f;
            r += (HIT_R - r) * k; g += (HIT_G - g) * k; b += (HIT_B - b) * k;
        }
        int rgb = ((int) r << 16) | ((int) g << 8) | (int) b;

        float bx = (float) (MathHelper.lerp(td, e.prevX, e.getX()) - cam.x);
        float by = (float) (MathHelper.lerp(td, e.prevY, e.getY()) - cam.y);
        float bz = (float) (MathHelper.lerp(td, e.prevZ, e.getZ()) - cam.z);
        Vector3f right = new Vector3f(1, 0, 0).rotate(camera.getRotation());
        Vector3f up = new Vector3f(0, 1, 0).rotate(camera.getRotation());

        switch (Modules.TARGETESP.mode) {
            case 0 -> drawGhosts(vc, m, bx, by, bz, right, up, e, alpha, rgb);
            case 1 -> drawRing(vc, m, bx, by, bz, e, alpha, rgb);
            case 2 -> drawSquare(vc, m, bx, by, bz, right, up, e, alpha, rgb);
            default -> drawOrbit(vc, m, bx, by, bz, e, alpha, rgb);
        }
    }

    // ---------------------------------------------------------------- Ghosts: glowing sweeps on 6 tilted circles
    private static void drawGhosts(VertexConsumer vc, Matrix4f m, float bx, float by, float bz, Vector3f right, Vector3f up,
                                   LivingEntity e, float alpha, int rgb) {
        float w = Math.max(e.getWidth(), 0.5f), h = Math.max(e.getHeight(), 0.5f), halfH = h / 2f;
        double radius = w + 0.3;
        int a255 = Math.max(1, (int) (alpha * 150f));
        int n = Math.min(Math.round(set(S_GHOST_COUNT)), GHOST_AXES.length);
        float gs = set(S_GHOST_SIZE);
        for (int i = 0; i < n; i++) {
            double ang0 = phase + i * Math.PI / 2.0;
            Vec3d axis = GHOST_AXES[i];
            Vec3d ref = Math.abs(axis.dotProduct(UP)) > 0.99 ? RIGHT : UP;
            Vec3d u = axis.crossProduct(ref).normalize();
            Vec3d v = axis.crossProduct(u).normalize();
            for (int k = 0; k < GHOST_PARTICLES; k++) {
                double ang = k * (GHOST_SWEEP_RAD / GHOST_PARTICLES) + ang0;
                Vec3d p = u.multiply(Math.cos(ang)).add(v.multiply(Math.sin(ang))).multiply(radius);
                float size = gs * (1f + k / (float) GHOST_PARTICLES);
                float px = bx + (float) p.x, py = by + halfH + (float) p.y, pz = bz + (float) p.z;
                bloom(vc, m, px, py, pz, right, up, size * 1.2f, 0xFFFFFF, (int) (a255 * 0.3f));   // soft white halo
                bloom(vc, m, px, py, pz, right, up, size, rgb, a255);
            }
        }
    }

    // ---------------------------------------------------------------- Ring: a ring running up and down the body
    private static void drawRing(VertexConsumer vc, Matrix4f m, float bx, float by, float bz, LivingEntity e, float alpha, int rgb) {
        float w = e.getWidth(), h = e.getHeight();
        float rad = w * 0.7f;
        float p = phase % (float) (Math.PI * 2);
        if (p < 0) p += (float) (Math.PI * 2);
        boolean down = p > Math.PI;
        float t = p / (float) Math.PI;
        float q = down ? t - 1f : 1f - t;
        float ease = easeInOutQuad(q);
        float trail = (h / 2f) * (ease <= 0.5f ? ease : 1f - ease) * (down ? -1f : 1f);
        float y = by + h * ease;
        int aTrail = (int) (100f * alpha), aBand = (int) (255f * alpha);
        int cTrail = Colors.argb(aTrail, rgb), cBand = Colors.argb(aBand, rgb), c0 = Colors.argb(0, rgb);
        float th = 0.03f;
        for (int deg = 0; deg < 360; deg += 2) {
            float a0 = (float) Math.toRadians(deg), a1 = (float) Math.toRadians(deg + 2);
            float x0 = MathHelper.cos(a0) * rad, z0 = MathHelper.sin(a0) * rad;
            float x1 = MathHelper.cos(a1) * rad, z1 = MathHelper.sin(a1) * rad;
            // fading trail behind the ring
            quad(vc, m, bx + x0, y, bz + z0, cTrail, bx + x1, y, bz + z1, cTrail,
                    bx + x1, y + trail, bz + z1, c0, bx + x0, y + trail, bz + z0, c0);
            // solid band
            quad(vc, m, bx + x0, y - th, bz + z0, cBand, bx + x1, y - th, bz + z1, cBand,
                    bx + x1, y + th, bz + z1, cBand, bx + x0, y + th, bz + z0, cBand);
        }
    }

    // ---------------------------------------------------------------- Square: a spinning target reticle in front of the body
    private static void drawSquare(VertexConsumer vc, Matrix4f m, float bx, float by, float bz, Vector3f right, Vector3f up,
                                   LivingEntity e, float alpha, int rgb) {
        float w = e.getWidth(), h = e.getHeight();
        Vec3d center = new Vec3d(bx, by + h / 2f, bz);
        Vec3d toCam = center.negate();                    // camera sits at the origin (everything is camera-relative)
        if (toCam.lengthSquared() > 1.0e-6) center = center.add(toCam.normalize().multiply(w));
        float size = set(S_SQUARE) * (1f + 0.05f * MathHelper.sin(phase)) * alpha;
        if (size <= 0.001f) return;

        double rot = Math.toRadians(rotation);
        float cr = (float) Math.cos(rot), sr = (float) Math.sin(rot);
        Vector3f ax = new Vector3f(right).mul(cr).add(new Vector3f(up).mul(sr));       // rotated right
        Vector3f ay = new Vector3f(up).mul(cr).sub(new Vector3f(right).mul(sr));       // rotated up
        int c = Colors.argb((int) (255f * alpha), rgb), c0 = Colors.argb(0, rgb);
        float cx = (float) center.x, cy = (float) center.y, cz = (float) center.z;
        float R = size * 0.5f;

        // left / right: curved brackets, top / bottom: chevrons pointing outwards
        for (int k = 0; k < 4; k++) {
            double ang = k * Math.PI / 2.0;
            float ux = (float) Math.cos(ang), uy = (float) Math.sin(ang);       // radial direction in the reticle plane
            float tx = -uy, ty = ux;                                              // tangent
            if (k % 2 == 0) {
                bracket(vc, m, cx, cy, cz, ax, ay, ang, R, c, c0);
            } else {
                // chevron: apex outwards, two legs sweeping back
                float[] pr = {0.50f, 0.28f, 0.18f, 0.40f, 0.18f, 0.28f};
                float[] pt = {0f, -0.19f, -0.19f, 0f, 0.19f, 0.19f};
                // quad strips: apex -> left leg, apex -> right leg
                float[] X = new float[6], Y = new float[6], Z = new float[6];
                for (int i = 0; i < 6; i++) {
                    float lx = (ux * pr[i] + tx * pt[i]) * size, ly = (uy * pr[i] + ty * pt[i]) * size;
                    X[i] = cx + ax.x * lx + ay.x * ly; Y[i] = cy + ax.y * lx + ay.y * ly; Z[i] = cz + ax.z * lx + ay.z * ly;
                }
                quad(vc, m, X[0], Y[0], Z[0], c, X[3], Y[3], Z[3], c, X[2], Y[2], Z[2], c, X[1], Y[1], Z[1], c);
                quad(vc, m, X[0], Y[0], Z[0], c, X[5], Y[5], Z[5], c, X[4], Y[4], Z[4], c, X[3], Y[3], Z[3], c);
            }
        }
        glow(vc, m, cx, cy, cz, right, up, R * 0.9f, 20, Colors.argb((int) (28f * alpha), rgb), c0);
    }

    /** curved bracket "(" centred on direction ang */
    private static void bracket(VertexConsumer vc, Matrix4f m, float cx, float cy, float cz, Vector3f ax, Vector3f ay,
                                double ang, float R, int c, int c0) {
        int segs = 8;
        double half = Math.toRadians(24);
        float rOut = R, rIn = R * 0.82f;
        for (int i = 0; i < segs; i++) {
            double a0 = ang - half + 2 * half * i / segs, a1 = ang - half + 2 * half * (i + 1) / segs;
            float[] p = new float[12];
            double[] aa = {a0, a1, a1, a0};
            float[] rr = {rIn, rIn, rOut, rOut};
            for (int j = 0; j < 4; j++) {
                float lx = (float) Math.cos(aa[j]) * rr[j], ly = (float) Math.sin(aa[j]) * rr[j];
                p[j * 3] = cx + ax.x * lx + ay.x * ly; p[j * 3 + 1] = cy + ax.y * lx + ay.y * ly; p[j * 3 + 2] = cz + ax.z * lx + ay.z * ly;
            }
            quad(vc, m, p[0], p[1], p[2], c, p[3], p[4], p[5], c, p[6], p[7], p[8], c, p[9], p[10], p[11], c);
        }
    }

    // ---------------------------------------------------------------- Orbit: layers of shapes circling the body
    private static void drawOrbit(VertexConsumer vc, Matrix4f m, float bx, float by, float bz, LivingEntity e, float alpha, int rgb) {
        float h = e.getHeight();
        int layers = Math.max(1, Math.round(set(S_ORBIT_LAYERS)));
        int count = Math.max(1, Math.round(set(S_ORBIT_COUNT)));
        float span = h * set(S_ORBIT_SPACING);
        float baseY = (h - span) / 2f;
        double mid = (layers - 1) / 2.0;
        float spin = tog(T_SPIN) ? rotation : 0f;
        int a = Math.max(1, (int) (alpha * 220f));
        float size = set(S_ORBIT_SIZE);
        int shape = cho(C_SHAPE);

        for (int l = 0; l < layers; l++) {
            float y = layers == 1 ? h / 2f : baseY + span * l / (layers - 1);
            double radius = (set(S_ORBIT_DIST) + MathHelper.sin(phase) * 0.08)
                    * (1.0 - Math.abs(l - mid) / Math.max(mid, 0.001) * 0.3);
            float offset = (360f / count) / 2f * (l % 2);
            for (int i = 0; i < count; i++) {
                double ang = Math.toRadians(spin + offset + 360.0 * i / count);
                Vec3d pos = new Vec3d(Math.cos(ang) * radius, y, Math.sin(ang) * radius);
                Vec3d dir = new Vec3d(0, y, 0).subtract(pos).normalize();                 // towards the body
                Vec3d side = new Vec3d(-dir.z, 0, dir.x).normalize();
                Vec3d upv = dir.crossProduct(side);
                Vec3d wp = pos.add(bx, by, bz);
                switch (shape) {
                    case 0 -> arrow(vc, m, wp, dir, side, upv, size, rgb, a);
                    case 1 -> rhomb(vc, m, wp, side, upv, size, rgb, a);
                    default -> cube(vc, m, wp, side, upv, size, rgb, a);
                }
            }
        }
    }

    /** pyramid pointing at the body */
    private static void arrow(VertexConsumer vc, Matrix4f m, Vec3d pos, Vec3d dir, Vec3d side, Vec3d up, float size, int rgb, int a) {
        Vec3d tip = pos.add(dir.multiply(size * 1.5));
        double hs = size / 2.0;
        Vec3d c0 = pos.add(side.multiply(hs)).add(up.multiply(hs));
        Vec3d c1 = pos.subtract(side.multiply(hs)).add(up.multiply(hs));
        Vec3d c2 = pos.subtract(side.multiply(hs)).subtract(up.multiply(hs));
        Vec3d c3 = pos.add(side.multiply(hs)).subtract(up.multiply(hs));
        int c = Colors.argb(a, rgb);
        tri(vc, m, tip, c0, c1, c); tri(vc, m, tip, c1, c2, c); tri(vc, m, tip, c2, c3, c); tri(vc, m, tip, c3, c0, c);
    }

    /** octahedron */
    private static void rhomb(VertexConsumer vc, Matrix4f m, Vec3d pos, Vec3d side, Vec3d up, float size, int rgb, int a) {
        double s = size * 0.6;
        Vec3d n = up.crossProduct(side);
        Vec3d top = pos.add(up.multiply(size * 1.2)), bot = pos.subtract(up.multiply(size * 1.2));
        Vec3d p1 = pos.add(side.multiply(s)), p2 = pos.add(n.multiply(s)), p3 = pos.subtract(side.multiply(s)), p4 = pos.subtract(n.multiply(s));
        int c = Colors.argb(a, rgb);
        tri(vc, m, top, p1, p2, c); tri(vc, m, top, p2, p3, c); tri(vc, m, top, p3, p4, c); tri(vc, m, top, p4, p1, c);
        tri(vc, m, bot, p2, p1, c); tri(vc, m, bot, p3, p2, c); tri(vc, m, bot, p4, p3, c); tri(vc, m, bot, p1, p4, c);
    }

    private static void cube(VertexConsumer vc, Matrix4f m, Vec3d pos, Vec3d side, Vec3d up, float size, int rgb, int a) {
        double hs = size / 2.0;
        Vec3d n = up.crossProduct(side);
        Vec3d[] cn = new Vec3d[8];
        for (int i = 0; i < 8; i++)
            cn[i] = pos.add(side.multiply((i & 1) != 0 ? hs : -hs)).add(up.multiply((i & 2) != 0 ? hs : -hs)).add(n.multiply((i & 4) != 0 ? hs : -hs));
        int c = Colors.argb(a, rgb);
        for (int[] f : CUBE_FACES) {
            tri(vc, m, cn[f[0]], cn[f[1]], cn[f[2]], c);
            tri(vc, m, cn[f[0]], cn[f[2]], cn[f[3]], c);
        }
    }

    // ---------------------------------------------------------------- math
    private static float easeInOutQuad(float t) {
        return t < 0.5f ? 2f * t * t : (float) (1.0 - Math.pow(-2.0 * t + 2.0, 2.0) / 2.0);
    }

    private static double smooth(double x) { return x * x * (3.0 - 2.0 * x); }

    // ---------------------------------------------------------------- vertex helpers (double-sided)
    private static void v(VertexConsumer vc, Matrix4f m, float x, float y, float z, int argb) {
        vc.vertex(m, x, y, z).color(argb);
    }

    private static void quad(VertexConsumer vc, Matrix4f m,
                             float x1, float y1, float z1, int c1, float x2, float y2, float z2, int c2,
                             float x3, float y3, float z3, int c3, float x4, float y4, float z4, int c4) {
        v(vc, m, x1, y1, z1, c1); v(vc, m, x2, y2, z2, c2); v(vc, m, x3, y3, z3, c3); v(vc, m, x4, y4, z4, c4);
        v(vc, m, x4, y4, z4, c4); v(vc, m, x3, y3, z3, c3); v(vc, m, x2, y2, z2, c2); v(vc, m, x1, y1, z1, c1);
    }

    private static void tri(VertexConsumer vc, Matrix4f m, Vec3d a, Vec3d b, Vec3d c, int argb) {
        quad(vc, m, (float) a.x, (float) a.y, (float) a.z, argb, (float) b.x, (float) b.y, (float) b.z, argb,
                (float) c.x, (float) c.y, (float) c.z, argb, (float) c.x, (float) c.y, (float) c.z, argb);
    }

    /** camera-facing soft disc: bright in the middle, fading to nothing (stands in for the bloom texture) */
    private static void glow(VertexConsumer vc, Matrix4f m, float x, float y, float z, Vector3f r, Vector3f u,
                             float rad, int n, int cIn, int cOut) {
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            float x0 = x + (r.x * c0 + u.x * s0) * rad, y0 = y + (r.y * c0 + u.y * s0) * rad, z0 = z + (r.z * c0 + u.z * s0) * rad;
            float x1 = x + (r.x * c1 + u.x * s1) * rad, y1 = y + (r.y * c1 + u.y * s1) * rad, z1 = z + (r.z * c1 + u.z * s1) * rad;
            quad(vc, m, x, y, z, cIn, x0, y0, z0, cOut, x1, y1, z1, cOut, x1, y1, z1, cOut);
        }
    }

    /** a billboard of the given size: strong core + soft outer falloff */
    private static void bloom(VertexConsumer vc, Matrix4f m, float x, float y, float z, Vector3f r, Vector3f u,
                              float size, int rgb, int a255) {
        if (a255 <= 0) return;
        float rad = size * 0.5f;
        glow(vc, m, x, y, z, r, u, rad, 12, Colors.argb(a255, rgb), Colors.argb(0, rgb));
        glow(vc, m, x, y, z, r, u, rad * 0.45f, 10, Colors.argb(a255, rgb), Colors.argb(a255 / 2, rgb));
    }
}
