package kz.alih.visuals.games.roulette;

import kz.alih.visuals.games.roulette.RouletteGame.Ph;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.List;

/** Draws the table, the two chairs, the revolver and the blood. Everything is built from shaded boxes. */
public final class RouletteScene {
    private RouletteScene() {}

    private static final int WOOD = 0x7A4B2A, WOOD_DARK = 0x4E2F1A, FELT = 0x1F5B3A, CHAIR = 0x5E3A22;
    private static final int STEEL = 0x3C4048, STEEL_LIGHT = 0x5A606B, GRIP = 0x70401F, BRASS = 0xC9A64B;
    private static final int BLOOD = 0x8A0C0C;

    private static final class Pose {
        final Vector3f p, d, u;
        Pose(Vector3f p, Vector3f d, Vector3f u) { this.p = p; this.d = d; this.u = u; }
    }

    private static float ease(float t) { t = MathHelper.clamp(t, 0f, 1f); return t * t * (3f - 2f * t); }
    private static float easeOut(float t) { t = MathHelper.clamp(t, 0f, 1f); float k = 1f - t; return 1f - k * k * k; }

    private static Pose lerp(Pose a, Pose b, float t) {
        return new Pose(new Vector3f(a.p).lerp(b.p, t), new Vector3f(a.d).lerp(b.d, t).normalize(), new Vector3f(a.u).lerp(b.u, t).normalize());
    }

    // ------------------------------------------------------------------ main entry (called from WorldRender)
    public static void render(RouletteGame g, VertexConsumer vc, Matrix4f m, Vec3d cam, Camera camera) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        Vector3f sx = new Vector3f((float) g.axisX, 0f, (float) g.axisZ);
        Vector3f sy = new Vector3f(0f, 1f, 0f);
        Vector3f sz = new Vector3f(-(float) g.axisZ, 0f, (float) g.axisX);
        Vector3f o = new Vector3f((float) (g.center.x - cam.x), (float) (g.center.y - cam.y), (float) (g.center.z - cam.z));
        Matrix4f S = new Matrix4f(m).translate(o).mul(basis(sx, sy, sz));

        float half = g.dist / 2f;
        float tableLen = MathHelper.clamp(g.dist - 1.0f, 0.9f, 1.5f);
        double age = (System.currentTimeMillis() - g.sceneT0) / 1000.0;
        float pop = easeOut((float) (age / 1.1));

        // ---- appear effect: expanding ring on the floor + sparkles rising around the table
        if (age < 2.2) {
            float k = (float) (age / 2.2);
            int a = (int) (200 * (1f - k));
            float r = 0.3f + 1.9f * easeOut(k);
            Draw3D.flatDisc(vc, S, 0, 0.02f, 0, r - 0.10f, r, 40, Draw3D.argb(0, 0x5CE1FF), Draw3D.argb(a, 0x5CE1FF));
            Draw3D.flatDisc(vc, S, 0, 0.02f, 0, r, r + 0.10f, 40, Draw3D.argb(a, 0x5CE1FF), Draw3D.argb(0, 0x5CE1FF));
            Vector3f right = new Vector3f(1, 0, 0).rotate(camera.getRotation()), up = new Vector3f(0, 1, 0).rotate(camera.getRotation());
            for (int i = 0; i < 18; i++) {
                double ang = i * 2.399963 + age * 0.9;
                float rad = 0.5f + (i % 4) * 0.22f;
                float y = (float) (((age * 0.9 + i * 0.37) % 1.8));
                float alpha = (float) Math.sin(Math.PI * (y / 1.8)) * (1f - k);
                Vector3f w = new Vector3f(o).add(new Vector3f(sx).mul((float) Math.cos(ang) * rad)).add(new Vector3f(sz).mul((float) Math.sin(ang) * rad)).add(0, y, 0);
                Draw3D.glow(vc, m, w.x, w.y, w.z, right, up, 0.05f, 8, Draw3D.argb((int) (230 * alpha), 0xBFF3FF), Draw3D.argb(0, 0x5CE1FF));
            }
        }

        // ---- table
        Matrix4f T = new Matrix4f(S).scale(0.7f + 0.3f * pop, pop, 0.7f + 0.3f * pop);
        float top = RouletteGame.TABLE_TOP;
        Draw3D.box(vc, T, 0, top - 0.035f, 0, tableLen / 2f, 0.035f, 0.47f, WOOD_DARK, 255);
        Draw3D.box(vc, T, 0, top + 0.001f, 0, tableLen / 2f - 0.05f, 0.003f, 0.42f, FELT, 255);
        for (int sxn = -1; sxn <= 1; sxn += 2) for (int szn = -1; szn <= 1; szn += 2)
            Draw3D.box(vc, T, sxn * (tableLen / 2f - 0.08f), (top - 0.07f) / 2f, szn * 0.38f, 0.035f, (top - 0.07f) / 2f, 0.035f, WOOD, 255);

        // ---- chairs (behind the players, facing the table)
        for (int side = 0; side < 2; side++) {
            boolean hostSide = side == 0;
            float cx = hostSide ? -half - 0.32f : half + 0.32f;
            Matrix4f C = new Matrix4f(S).translate(cx, 0, 0);
            if (!hostSide) C.rotateY((float) Math.PI);
            C.scale(0.8f + 0.2f * pop, pop, 0.8f + 0.2f * pop);
            boolean loser = g.loserIsHost != null && g.loserIsHost == hostSide;
            if (loser && (g.ph == Ph.BANG || g.ph == Ph.DONE)) {
                double e = g.ph == Ph.DONE ? 9 : g.e();
                float tip = 80f * ease((float) ((e - 0.9) / 0.8));
                C.translate(-0.24f, 0, 0).rotateZ((float) Math.toRadians(tip)).translate(0.24f, 0, 0);
            }
            chair(vc, C);
        }

        // ---- blood on the table / floor
        for (float[] sp : g.splats) {
            float r = sp[3];
            Draw3D.flatDisc(vc, S, sp[0], sp[1], sp[2], 0f, r, 8, Draw3D.argb(235, BLOOD), Draw3D.argb(200, Draw3D.shade(BLOOD, 0.8f)));
        }
        if (g.loserIsHost != null && (g.ph == Ph.BANG || g.ph == Ph.DONE)) {
            double e = g.ph == Ph.DONE ? 9 : g.e();
            float grow = easeOut((float) ((e - 0.6) / 2.6));
            float px = (g.loserIsHost ? -1 : 1) * (tableLen / 2f - 0.22f);
            Draw3D.flatDisc(vc, S, px, top + 0.006f, 0.02f, 0f, 0.28f * grow, 18, Draw3D.argb(245, 0x7A0808), Draw3D.argb(220, 0x5E0606));
        }
        Vector3f right = new Vector3f(1, 0, 0).rotate(camera.getRotation()), up = new Vector3f(0, 1, 0).rotate(camera.getRotation());
        for (float[] d : g.drops) {
            Vector3f w = new Vector3f(o).add(new Vector3f(sx).mul(d[0])).add(new Vector3f(sy).mul(d[1])).add(new Vector3f(sz).mul(d[2]));
            Draw3D.glow(vc, m, w.x, w.y, w.z, right, up, 0.018f, 6, Draw3D.argb(255, 0xB01010), Draw3D.argb(220, 0x7A0808));
        }

        // ---- revolver
        drawRevolver(g, vc, m, S, sx, sy, sz, o, camera, half);
    }

    private static Matrix4f basis(Vector3f x, Vector3f y, Vector3f z) {
        return new Matrix4f(x.x, x.y, x.z, 0f, y.x, y.y, y.z, 0f, z.x, z.y, z.z, 0f, 0f, 0f, 0f, 1f);
    }

    /** origin + the direction of the barrel (x) and the "up" of the gun (y) -> matrix for drawing in gun space */
    private static Matrix4f gunFrame(Matrix4f m, Pose p) {
        Vector3f x = new Vector3f(p.d).normalize();
        Vector3f z = new Vector3f(x).cross(p.u).normalize();
        Vector3f y = new Vector3f(z).cross(x).normalize();
        return new Matrix4f(m).translate(p.p).mul(basis(x, y, z));
    }

    private static void chair(VertexConsumer vc, Matrix4f c) {
        Draw3D.box(vc, c, 0, 0.46f, 0, 0.24f, 0.025f, 0.24f, CHAIR, 255);
        for (int a = -1; a <= 1; a += 2) for (int b = -1; b <= 1; b += 2)
            Draw3D.box(vc, c, a * 0.2f, 0.22f, b * 0.2f, 0.022f, 0.22f, 0.022f, Draw3D.shade(CHAIR, 0.85f), 255);
        Draw3D.box(vc, c, -0.22f, 0.78f, 0, 0.02f, 0.3f, 0.24f, CHAIR, 255);
        Draw3D.box(vc, c, -0.22f, 0.9f, 0, 0.025f, 0.03f, 0.25f, Draw3D.shade(CHAIR, 1.2f), 255);
    }

    // ------------------------------------------------------------------ the gun
    private static Pose tablePose(Matrix4f unused, Vector3f o, Vector3f sx, Vector3f sy, Vector3f sz, float angleDeg, float lx, float lz) {
        double a = Math.toRadians(angleDeg);
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        Vector3f p = loc(o, sx, sy, sz, lx, RouletteGame.TABLE_TOP + 0.035f, lz);
        Vector3f d = new Vector3f(sx).mul(c).add(new Vector3f(sz).mul(s));
        Vector3f u = new Vector3f(sx).mul(-s).add(new Vector3f(sz).mul(c));
        return new Pose(p, d, u);
    }

    private static Vector3f loc(Vector3f o, Vector3f sx, Vector3f sy, Vector3f sz, float x, float y, float z) {
        return new Vector3f(o).add(new Vector3f(sx).mul(x)).add(new Vector3f(sy).mul(y)).add(new Vector3f(sz).mul(z));
    }

    private static void drawRevolver(RouletteGame g, VertexConsumer vc, Matrix4f m, Matrix4f S, Vector3f sx, Vector3f sy, Vector3f sz,
                                     Vector3f o, Camera camera, float half) {
        // camera basis for the poses glued to the view of the local player
        Vec3d fw = Vec3d.fromPolar(camera.getPitch(), camera.getYaw());
        Vector3f F = new Vector3f((float) fw.x, (float) fw.y, (float) fw.z).normalize();
        Vector3f R = new Vector3f(-F.z, 0f, F.x).normalize();
        Vector3f U = new Vector3f(R).cross(F).normalize();

        float a0 = 90f;
        float th = g.theta;
        float spinFinal = a0 + 1080f + (((th - a0) % 360f) + 360f) % 360f;
        double e = g.e();
        float ef = (float) e;

        Pose table0 = tablePose(null, o, sx, sy, sz, a0, 0, 0);
        Pose tableFinal = tablePose(null, o, sx, sy, sz, th, 0, 0);

        boolean hostHolds = g.ph == Ph.TAKE || g.ph == Ph.LOAD || g.ph == Ph.SPIN || g.ph == Ph.PUT;
        boolean holdSideHost = hostHolds ? true : g.shooterIsHost;
        boolean holderIsMe = hostHolds ? g.host : g.shooterIsMe();

        Pose hand = holderIsMe ? camHand(R, U, F, g.ph == Ph.LOAD) : sceneHand(o, sx, sy, sz, holdSideHost, half, g.ph == Ph.LOAD);
        Pose temple = holderIsMe ? camTemple(R, U, F) : sceneTemple(o, sx, sy, sz, holdSideHost, half);

        Pose pose = table0;
        float cyl = 0f;
        boolean open = false, bullet = false;
        float flash = 0f;

        switch (g.ph) {
            case INTRO -> pose = table0;
            case TAKE -> pose = lerp(table0, hand, ease(ef / 1.0f));
            case LOAD -> {
                pose = hand;
                open = ef > 0.3f && ef < 1.75f;
                bullet = ef > 0.9f;
            }
            case SPIN -> { pose = hand; bullet = true; cyl = 40f * (1f - (1f - Math.min(1f, ef / 2.0f)) * (1f - Math.min(1f, ef / 2.0f))); }
            case PUT -> { pose = lerp(hand, table0, ease(ef / 0.8f)); bullet = true; }
            case TSPIN -> pose = tablePose(null, o, sx, sy, sz, a0 + (spinFinal - a0) * easeOut(ef / 3.6f), 0, 0);
            case POINT -> pose = tableFinal;
            case PICK -> pose = lerp(tableFinal, hand, ease(ef / 0.8f));
            case RAISE -> pose = lerp(hand, temple, ease(ef / 1.3f));
            case AWAIT, TENSION -> {
                pose = temple;
                float tr = 0.004f;
                pose = new Pose(new Vector3f(temple.p).add((float) Math.sin(System.currentTimeMillis() / 70.0) * tr, (float) Math.cos(System.currentTimeMillis() / 83.0) * tr, 0), temple.d, temple.u);
            }
            case CLICK -> pose = ef < 0.5f ? lerp(temple, hand, ease(ef / 0.5f)) : lerp(hand, tableFinal, ease((ef - 0.5f) / 0.9f));
            case BANG -> {
                float k = Math.max(0f, 1f - ef * 6f);
                Vector3f dir = new Vector3f(temple.d).lerp(new Vector3f(temple.u), 0.55f * k).normalize();
                Vector3f p = new Vector3f(temple.p).sub(new Vector3f(temple.d).mul(0.10f * k));
                Pose kick = new Pose(p, dir, temple.u);
                pose = ef < 0.55f ? kick : lerp(kick, tableFinal, ease((ef - 0.55f) / 0.45f));
                flash = Math.max(0f, 1f - ef / 0.14f);
                bullet = false;
            }
            default -> pose = tableFinal;
        }
        if (g.ph == Ph.CLICK || g.ph == Ph.PICK || g.ph == Ph.RAISE || g.ph == Ph.AWAIT || g.ph == Ph.TENSION || g.ph == Ph.POINT) bullet = false;

        drawGun(vc, gunFrame(m, pose), cyl, open, bullet, flash);
    }

    private static Pose camHand(Vector3f R, Vector3f U, Vector3f F, boolean loading) {
        Vector3f p = new Vector3f(R).mul(0.20f).sub(new Vector3f(U).mul(0.20f)).add(new Vector3f(F).mul(0.46f));
        Vector3f d = new Vector3f(F).mul(0.95f).add(new Vector3f(U).mul(loading ? 0.45f : 0.05f)).normalize();
        Vector3f u = new Vector3f(U).sub(new Vector3f(d).mul(d.dot(U))).normalize();
        return new Pose(p, d, loading ? new Vector3f(u).add(new Vector3f(R).mul(0.55f)).normalize() : u);
    }

    private static Pose camTemple(Vector3f R, Vector3f U, Vector3f F) {
        Vector3f p = new Vector3f(R).mul(0.24f).sub(new Vector3f(U).mul(0.03f)).add(new Vector3f(F).mul(0.30f));
        Vector3f d = new Vector3f(R).mul(-0.9f).sub(new Vector3f(F).mul(0.45f)).normalize();
        return new Pose(p, d, new Vector3f(U));
    }

    private static Pose sceneHand(Vector3f o, Vector3f sx, Vector3f sy, Vector3f sz, boolean hostSide, float half, boolean loading) {
        float t = hostSide ? 1f : -1f, seat = hostSide ? -half : half;
        Vector3f p = loc(o, sx, sy, sz, seat + t * 0.42f, 1.12f, 0.14f);
        Vector3f d = new Vector3f(sx).mul(t * 0.92f).add(new Vector3f(sy).mul(loading ? 0.4f : 0.05f)).normalize();
        Vector3f u = new Vector3f(sy).sub(new Vector3f(d).mul(d.dot(sy))).normalize();
        return new Pose(p, d, u);
    }

    private static Pose sceneTemple(Vector3f o, Vector3f sx, Vector3f sy, Vector3f sz, boolean hostSide, float half) {
        float t = hostSide ? 1f : -1f, seat = hostSide ? -half : half;
        Vector3f p = loc(o, sx, sy, sz, seat + t * 0.10f, 1.60f, 0.16f);
        Vector3f d = new Vector3f(sx).mul(-t * 0.10f).add(new Vector3f(sz).mul(-0.16f)).normalize();
        return new Pose(p, d, new Vector3f(sy));
    }

    /** a revolver in its own space: barrel along +X, grip down (-Y), about 0.35 m long */
    private static void drawGun(VertexConsumer vc, Matrix4f f, float cylAng, boolean open, boolean bullet, float flash) {
        // frame + barrel
        Draw3D.box(vc, f, 0f, 0f, 0f, 0.055f, 0.032f, 0.012f, STEEL, 255);
        Draw3D.box(vc, f, 0.20f, 0.034f, 0f, 0.15f, 0.011f, 0.011f, STEEL, 255);
        Draw3D.box(vc, f, 0.20f, 0.047f, 0f, 0.14f, 0.003f, 0.006f, STEEL_LIGHT, 255);
        Draw3D.box(vc, f, 0.345f, 0.052f, 0f, 0.005f, 0.007f, 0.003f, STEEL_LIGHT, 255);
        // cylinder: six boxes around the X axis (swings out to the side while loading)
        float zOff = open ? 0.05f : 0f;
        Matrix4f cm = new Matrix4f(f).translate(0.035f, 0.018f, zOff);
        Draw3D.box(vc, cm, 0f, 0f, 0f, 0.047f, 0.012f, 0.012f, Draw3D.shade(STEEL, 0.7f), 255);
        for (int k = 0; k < 6; k++) {
            Matrix4f c = new Matrix4f(cm).rotateX(cylAng + k * (float) Math.PI / 3f).translate(0f, 0.026f, 0f);
            Draw3D.box(vc, c, 0f, 0f, 0f, 0.045f, 0.0125f, 0.0125f, k == 0 ? STEEL_LIGHT : STEEL, 255);
            if (bullet && k == 0) Draw3D.box(vc, c, 0.0f, 0.004f, 0f, 0.038f, 0.007f, 0.007f, BRASS, 255);
        }
        // hammer, trigger, guard
        Draw3D.box(vc, f, -0.062f, 0.048f, 0f, 0.012f, 0.014f, 0.004f, STEEL, 255);
        Draw3D.box(vc, f, -0.012f, -0.022f, 0f, 0.003f, 0.010f, 0.003f, STEEL_LIGHT, 255);
        Draw3D.box(vc, f, -0.012f, -0.042f, 0f, 0.032f, 0.003f, 0.006f, STEEL, 255);
        Draw3D.box(vc, f, 0.02f, -0.030f, 0f, 0.003f, 0.013f, 0.006f, STEEL, 255);
        // wooden grip, tilted back
        Matrix4f g = new Matrix4f(f).translate(-0.078f, -0.05f, 0f).rotateZ(-0.38f);
        Draw3D.box(vc, g, 0f, -0.03f, 0f, 0.023f, 0.058f, 0.0155f, GRIP, 255);
        Draw3D.box(vc, g, 0f, -0.09f, 0f, 0.026f, 0.006f, 0.017f, STEEL, 255);
        // muzzle flash
        if (flash > 0.01f) {
            int a = (int) (255 * flash);
            float s = 0.05f + 0.12f * flash;
            Draw3D.box(vc, f, 0.36f + s, 0.034f, 0f, s, 0.012f * flash + 0.002f, 0.012f * flash + 0.002f, 0xFFE9A0, a);
            Draw3D.box(vc, f, 0.36f + s * 0.4f, 0.034f, 0f, s * 0.5f, 0.02f * flash, 0.02f * flash, 0xFFFFFF, a);
            Draw3D.box(vc, f, 0.36f + s * 0.4f, 0.034f, 0f, s * 0.5f, 0.004f, 0.03f * flash, 0xFFC060, a);
            Draw3D.box(vc, f, 0.36f + s * 0.4f, 0.034f, 0f, s * 0.5f, 0.03f * flash, 0.004f, 0xFFC060, a);
        }
    }
}
