package kz.alih.visuals.games;

import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Transport between two AlihVisuals clients: a private whisper (/msg nick AVG1|from|type|data|) that the receiving
 * client swallows, so nobody sees it in chat. Works on any server that has /msg; no extra server needed.
 * The command can be changed in config/alihvisuals_games.properties (whisper=msg | w | tell ...).
 */
public final class GameNet {
    private static final Pattern P = Pattern.compile("AVG1\\|([A-Za-z0-9_]{1,16})\\|([a-z0-9]{1,6})\\|([^|\\s]{0,180})\\|");
    private static final ArrayDeque<String[]> QUEUE = new ArrayDeque<>();
    private static final long GAP_MS = 350L;      // servers kick for chat spam - never send faster than this
    private static long lastSend;
    private static String whisper = "msg";

    private GameNet() {}

    public static void init() {
        try {
            Path f = FabricLoader.getInstance().getConfigDir().resolve("alihvisuals_games.properties");
            Properties p = new Properties();
            if (Files.exists(f)) {
                try (var in = Files.newInputStream(f)) { p.load(in); }
            } else {
                p.setProperty("whisper", "msg");
                try (var out = Files.newOutputStream(f)) { p.store(out, "Command used to send private game messages (msg, w, tell, m ...)"); }
            }
            String w = p.getProperty("whisper", "msg").trim();
            if (w.startsWith("/")) w = w.substring(1);
            if (!w.isEmpty()) whisper = w;
        } catch (Exception ignored) {}

        ClientReceiveMessageEvents.ALLOW_GAME.register((msg, overlay) -> !intercept(msg.getString()));
        ClientReceiveMessageEvents.ALLOW_CHAT.register((msg, signed, sender, params, ts) -> !intercept(msg.getString()));
    }

    public static String self() {
        return MinecraftClient.getInstance().getSession().getUsername();
    }

    /** queue a message for the other player (type 1-6 chars a-z0-9, data without '|' and spaces) */
    public static void send(String to, String type, String data) {
        QUEUE.add(new String[]{to, "AVG1|" + self() + "|" + type + "|" + (data == null ? "" : data.replace('|', '/').replace(' ', '_')) + "|"});
    }

    public static void tick(MinecraftClient mc) {
        if (QUEUE.isEmpty() || mc.getNetworkHandler() == null) return;
        long now = System.currentTimeMillis();
        if (now - lastSend < GAP_MS) return;
        String[] m = QUEUE.poll();
        lastSend = now;
        mc.getNetworkHandler().sendChatCommand(whisper + " " + m[0] + " " + m[1]);
    }

    public static void clear() { QUEUE.clear(); }

    /** @return true if the text was one of our game messages (it is then hidden from chat) */
    private static boolean intercept(String text) {
        Matcher m = P.matcher(text);
        if (!m.find()) return false;
        String from = m.group(1), type = m.group(2), data = m.group(3);
        if (from.equalsIgnoreCase(self())) return true;           // echo of my own whisper
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.execute(() -> GameHub.dispatch(from, type, data));
        return true;
    }
}
