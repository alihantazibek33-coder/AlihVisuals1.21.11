package kz.alih.visuals.games;

import kz.alih.visuals.AlihUsers;
import kz.alih.visuals.games.chess.ChessGame;
import kz.alih.visuals.games.chess.ChessScreen;
import kz.alih.visuals.games.roulette.RouletteGame;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/** Invites, accepting, and the one game that is running right now. */
public final class GameHub {
    private GameHub() {}

    public enum Kind {
        CHESS("Шахмат", "chess"), ROULETTE("Орыс рулеткасы", "roul");
        public final String title, id;
        Kind(String title, String id) { this.title = title; this.id = id; }
        static Kind of(String id) { for (Kind k : values()) if (k.id.equals(id)) return k; return null; }
    }

    public interface Game {
        String opponent();
        Kind kind();
        void onMessage(String type, String data);
        void tick(MinecraftClient mc);
        void onClosed();
        /** true while the player must sit still (movement keys are released) */
        boolean locksPlayer();
        /** start of every client tick (before the game reads the keys) */
        default void startTick(MinecraftClient mc) {}
    }

    public static final double ROULETTE_MAX_DIST = 5.0, ROULETTE_MIN_DIST = 1.6;
    private static final long INVITE_TIMEOUT_MS = 30_000L;

    private static Game active;
    private static String outTo;  private static Kind outKind;  private static long outAt;
    private static String inFrom; private static Kind inKind;   private static long inAt;
    private static String status = "";

    public static Game active() { return active; }
    public static String status() { return status; }
    public static String incomingFrom() { return inFrom; }
    public static Kind incomingKind() { return inKind; }
    public static boolean hasOutgoing() { return outTo != null; }

    private static void say(String s, Formatting f) {
        status = s;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.sendMessage(Text.literal("[Games] ").formatted(Formatting.AQUA).append(Text.literal(s).formatted(f)), false);
    }

    // ------------------------------------------------------------------ players
    public static PlayerListEntry entryOf(String nick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(nick);
    }

    /** online players who use AlihVisuals (and so can play), without yourself */
    public static List<String> clientPlayers() {
        List<String> out = new ArrayList<>();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() == null) return out;
        for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {
            String n = e.getProfile().name();
            if (n.equalsIgnoreCase(GameNet.self())) continue;
            if (AlihUsers.has(e.getProfile().id())) out.add(n);
        }
        return out;
    }

    public static AbstractClientPlayerEntity playerNear(String nick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return null;
        for (AbstractClientPlayerEntity p : mc.world.getPlayers())
            if (p.getName().getString().equalsIgnoreCase(nick)) return p;
        return null;
    }

    /** null = fine, otherwise the reason why the game can't be played with this nick */
    private static String check(Kind kind, String nick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.getNetworkHandler() == null) return "Серверге кір";
        if (active != null) return "Сен қазір ойындасың";
        if (nick == null || nick.isBlank()) return "Ник жаз";
        if (nick.equalsIgnoreCase(GameNet.self())) return "Өзіңмен ойнай алмайсың";
        PlayerListEntry e = entryOf(nick);
        if (e == null) return nick + " серверде жоқ";
        if (!AlihUsers.has(e.getProfile().id()))
            return nick + " клиентті қолданбайды (тізім 60 сек сайын жаңарады)";
        if (kind == Kind.ROULETTE) {
            AbstractClientPlayerEntity p = playerNear(nick);
            if (p == null) return nick + " жақын жерде емес (5 блок ішінде тұру керек)";
            double d = p.distanceTo(mc.player);
            if (d > ROULETTE_MAX_DIST) return String.format("Алыс тұр: %.1f блок (керегі ≤ 5)", d);
            if (d < ROULETTE_MIN_DIST) return "Тым жақын тұр - ең аз 2 блок";
        }
        return null;
    }

    // ------------------------------------------------------------------ inviting
    /** @return error text or null when the invite was sent */
    public static String invite(Kind kind, String nick) {
        String err = check(kind, nick);
        if (err != null) { status = err; return err; }
        PlayerListEntry e = entryOf(nick);
        outTo = e.getProfile().name(); outKind = kind; outAt = System.currentTimeMillis();
        GameNet.send(outTo, "inv", kind.id);
        status = outTo + " жауап күтілуде...";
        return null;
    }

    public static void cancelInvite() { outTo = null; status = ""; }

    public static void acceptIncoming() {
        if (inFrom == null) return;
        String from = inFrom; Kind k = inKind;
        inFrom = null;
        String err = check(k, from);
        if (err != null) { GameNet.send(from, "dec", "x"); say(err, Formatting.RED); return; }
        GameNet.send(from, "acc", k.id);
        start(k, from, false);
    }

    public static void declineIncoming() {
        if (inFrom == null) return;
        GameNet.send(inFrom, "dec", "no");
        inFrom = null;
    }

    // ------------------------------------------------------------------ messages from the other client
    static void dispatch(String from, String type, String data) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        switch (type) {
            case "inv" -> {
                Kind k = Kind.of(data);
                if (k == null) return;
                if (active != null || inFrom != null) { GameNet.send(from, "dec", "busy"); return; }
                inFrom = from; inKind = k; inAt = System.currentTimeMillis();
                mc.setScreen(new InviteScreen());
            }
            case "acc" -> {
                if (outTo != null && outTo.equalsIgnoreCase(from) && Kind.of(data) == outKind) {
                    Kind k = outKind;
                    String nick = outTo;
                    outTo = null;
                    String err = check(k, nick);
                    if (err != null) { say(err, Formatting.RED); GameNet.send(nick, "end", "x"); return; }
                    start(k, nick, true);
                }
            }
            case "dec" -> {
                if (outTo != null && outTo.equalsIgnoreCase(from)) {
                    outTo = null;
                    say(from + " бас тартты", Formatting.YELLOW);
                }
            }
            case "end" -> {
                if (active != null && active.opponent().equalsIgnoreCase(from)) {
                    say(from + " ойыннан шықты", Formatting.YELLOW);
                    closeActive(false);
                }
            }
            default -> { if (active != null && active.opponent().equalsIgnoreCase(from)) active.onMessage(type, data); }
        }
    }

    private static void start(Kind k, String opponent, boolean host) {
        MinecraftClient mc = MinecraftClient.getInstance();
        switch (k) {
            case CHESS -> { ChessGame g = new ChessGame(opponent, host); active = g; mc.setScreen(new ChessScreen(g)); }
            case ROULETTE -> { RouletteGame g = new RouletteGame(opponent, host); active = g; mc.setScreen(null); }
        }
        status = "";
    }

    /** leave the current game (tells the other player when notify is true) */
    public static void closeActive(boolean notify) {
        Game g = active;
        if (g == null) return;
        active = null;
        if (notify) GameNet.send(g.opponent(), "end", "x");
        g.onClosed();
        GameCamera.reset();
    }

    // ------------------------------------------------------------------ ticks
    /** start of the client tick: keep the player seated */
    public static void startTick(MinecraftClient mc) {
        GameNet.tick(mc);
        if (active != null && mc.player != null) active.startTick(mc);
        if (active != null && active.locksPlayer() && mc.player != null) {
            mc.options.forwardKey.setPressed(false); mc.options.backKey.setPressed(false);
            mc.options.leftKey.setPressed(false); mc.options.rightKey.setPressed(false);
            mc.options.jumpKey.setPressed(false); mc.options.sprintKey.setPressed(false);
            mc.options.sneakKey.setPressed(false);
        }
    }

    public static void tick(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        if (mc.world == null || mc.player == null) {
            if (active != null) closeActive(false);
            outTo = null; inFrom = null; GameNet.clear();
            return;
        }
        if (outTo != null && now - outAt > INVITE_TIMEOUT_MS) { say(outTo + " жауап бермеді", Formatting.YELLOW); outTo = null; }
        if (inFrom != null && now - inAt > INVITE_TIMEOUT_MS) inFrom = null;
        if (active != null) active.tick(mc);
    }
}
