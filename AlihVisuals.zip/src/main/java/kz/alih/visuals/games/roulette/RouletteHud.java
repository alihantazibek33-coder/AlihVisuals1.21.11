package kz.alih.visuals.games.roulette;

import kz.alih.visuals.games.GUi;
import kz.alih.visuals.games.GameHub;
import kz.alih.visuals.games.roulette.RouletteGame.Ph;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/** on-screen part of the roulette: hints, flash, blood, black-out. Also advances the per-frame animation. */
public final class RouletteHud {
    private RouletteHud() {}

    public static void render(DrawContext c, RenderTickCounter tc) {
        if (!(GameHub.active() instanceof RouletteGame g)) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        g.frame(mc);
        int w = c.getScaledWindowWidth(), h = c.getScaledWindowHeight();
        var tr = mc.textRenderer;

        // blood creeping in from the edges
        if (g.blood > 0.01f) {
            int a = (int) (255 * g.blood);
            int edge = Math.max(10, h / 3);
            c.fillGradient(0, 0, w, edge, (a << 24) | 0x7A0000, 0x007A0000);
            c.fillGradient(0, h - edge, w, h, 0x007A0000, (a << 24) | 0x7A0000);
            c.fill(0, 0, w / 14, h, ((a / 2) << 24) | 0x7A0000);
            c.fill(w - w / 14, 0, w, h, ((a / 2) << 24) | 0x7A0000);
        }
        if (g.flash > 0.01f) c.fill(0, 0, w, h, ((int) (255 * Math.min(1f, g.flash)) << 24) | 0xFFFFFF);
        if (g.black > 0.01f) c.fill(0, 0, w, h, ((int) (255 * g.black) << 24));

        String line = null, sub = null;
        int col = 0xFFE6E9EF;
        double e = g.e();
        switch (g.ph) {
            case INTRO -> line = "Ойын басталуда...";
            case TAKE, LOAD, SPIN, PUT -> line = g.host ? "Сен тапаншаны оқтап жатырсың" : g.opponent() + " тапаншаны оқтап жатыр...";
            case TSPIN -> line = "Тапанша айналуда...";
            case POINT -> {
                line = "Тапаншаның басы " + (g.starterIsHost == g.host ? "саған" : g.opponent() + " жаққа") + " қарады";
                sub = g.starterIsHost == g.host ? "Сен бастайсың!" : g.opponent() + " бастайды";
                col = 0xFFFFC66B;
            }
            case PICK, RAISE -> line = g.shooterIsMe() ? "Тапаншаны алдың..." : g.opponent() + " тапаншаны алды...";
            case AWAIT -> {
                if (g.shooterIsMe()) {
                    line = "ШҮРІППЕНІ БАС  (тышқан батырмасы)";
                    float pulse = 0.5f + 0.5f * (float) Math.sin(System.currentTimeMillis() / 160.0);
                    col = (0xFF << 24) | ((int) (200 + 55 * pulse) << 16) | ((int) (70 + 40 * pulse) << 8) | 0x60;
                } else line = g.opponent() + " шүріппені басуға дайындалуда...";
            }
            case TENSION -> line = "...";
            case CLICK -> {
                line = "Клик! Оқ жоқ";
                sub = g.shooterIsMe() ? g.opponent() + " кезегі" : "Сенің кезегің";
                col = 0xFF56E07A;
            }
            case BANG -> { if (e < 1.6) { GUi.bigText(c, tr, "БАХ!", w / 2f, h / 2f - 30, 5f, 0xFFFF3030); } }
            default -> { }
        }
        if (line != null) {
            GUi.bigText(c, tr, line, w / 2f, h - 58, 1.4f, col);
            if (sub != null) GUi.bigText(c, tr, sub, w / 2f, h - 38, 1.1f, 0xFFB8BFCC);
        }
    }
}
