package kz.alih.visuals.games.chess;

import kz.alih.visuals.games.GameHub;
import kz.alih.visuals.games.GameNet;
import net.minecraft.client.MinecraftClient;

/** one chess match between me and the opponent (messages: mv e2e4[q], rs = resign, rm = rematch) */
public class ChessGame implements GameHub.Game {
    private final String opponent;
    public ChessEngine engine = new ChessEngine();
    public boolean myWhite;
    public String result = "";            // empty while playing
    public boolean iWantRematch, oppWantsRematch;

    public ChessGame(String opponent, boolean host) {
        this.opponent = opponent;
        this.myWhite = host;                 // the one who invited plays white; rematch swaps colours
    }

    @Override public String opponent() { return opponent; }
    @Override public GameHub.Kind kind() { return GameHub.Kind.CHESS; }
    @Override public void tick(MinecraftClient mc) {}
    @Override public void onClosed() {}
    @Override public boolean locksPlayer() { return false; }

    public boolean myTurn() { return result.isEmpty() && engine.whiteToMove == myWhite; }

    /** my move from the board */
    public boolean play(int from, int to, char promo) {
        if (!myTurn()) return false;
        ChessEngine.Move m = engine.find(from, to, promo);
        if (m == null) return false;
        engine.apply(m);
        GameNet.send(opponent, "mv", ChessEngine.name(from) + ChessEngine.name(to) + (m.promo() != '\0' ? String.valueOf(m.promo()) : ""));
        checkEnd();
        return true;
    }

    public void resign() {
        if (!result.isEmpty()) return;
        GameNet.send(opponent, "rs", "x");
        result = "Сен берілдің - " + opponent + " жеңді";
    }

    public void askRematch() {
        if (result.isEmpty()) return;
        iWantRematch = true;
        GameNet.send(opponent, "rm", "x");
        maybeRestart();
    }

    private void maybeRestart() {
        if (iWantRematch && oppWantsRematch) {
            engine = new ChessEngine();
            myWhite = !myWhite;
            result = "";
            iWantRematch = oppWantsRematch = false;
        }
    }

    private void checkEnd() {
        switch (engine.status()) {
            case CHECKMATE -> {
                boolean whiteWon = !engine.whiteToMove;
                result = "Мат! " + (whiteWon ? "Ақтар" : "Қаралар") + " жеңді" + (whiteWon == myWhite ? " - сен жеңдің!" : " - сен ұттырдың");
            }
            case STALEMATE -> result = "Пат - тең ойын";
            case DRAW -> result = "Материал жетпейді - тең ойын";
            default -> {}
        }
    }

    @Override
    public void onMessage(String type, String data) {
        switch (type) {
            case "mv" -> {
                if (!result.isEmpty() || data.length() < 4 || engine.whiteToMove == myWhite) return;
                try {
                    int from = ChessEngine.sq(data.substring(0, 2)), to = ChessEngine.sq(data.substring(2, 4));
                    char promo = data.length() > 4 ? data.charAt(4) : '\0';
                    ChessEngine.Move m = engine.find(from, to, promo);
                    if (m == null) return;                       // illegal move from the other side: ignored
                    engine.apply(m);
                    checkEnd();
                } catch (RuntimeException ignored) {}
            }
            case "rs" -> { if (result.isEmpty()) result = opponent + " берілді - сен жеңдің!"; }
            case "rm" -> { oppWantsRematch = true; maybeRestart(); }
            default -> {}
        }
    }
}
