package kz.alih.visuals.games.roulette;

import net.minecraft.client.render.VertexConsumer;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/** vertex-colour drawing helpers for the roulette scene (boxes with fake per-face lighting, discs) */
final class Draw3D {
    private Draw3D() {}

    static int argb(int a, int rgb) { return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF); }

    static int shade(int rgb, float f) {
        int r = (int) (((rgb >> 16) & 255) * f), g = (int) (((rgb >> 8) & 255) * f), b = (int) ((rgb & 255) * f);
        return (Math.min(255, r) << 16) | (Math.min(255, g) << 8) | Math.min(255, b);
    }

    private static void v(VertexConsumer vc, Matrix4f m, float x, float y, float z, int c) { vc.vertex(m, x, y, z).color(c); }

    /** double sided quad (so winding never matters) */
    static void quad(VertexConsumer vc, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2,
                     float x3, float y3, float z3, float x4, float y4, float z4, int c) {
        v(vc, m, x1, y1, z1, c); v(vc, m, x2, y2, z2, c); v(vc, m, x3, y3, z3, c); v(vc, m, x4, y4, z4, c);
        v(vc, m, x4, y4, z4, c); v(vc, m, x3, y3, z3, c); v(vc, m, x2, y2, z2, c); v(vc, m, x1, y1, z1, c);
    }

    /** axis aligned box in the space of m: centre + half sizes. Faces get different brightness so it reads as 3D. */
    static void box(VertexConsumer vc, Matrix4f m, float cx, float cy, float cz, float hx, float hy, float hz, int rgb, int alpha) {
        float x0 = cx - hx, x1 = cx + hx, y0 = cy - hy, y1 = cy + hy, z0 = cz - hz, z1 = cz + hz;
        int top = argb(alpha, shade(rgb, 1.00f)), bot = argb(alpha, shade(rgb, 0.45f));
        int sx = argb(alpha, shade(rgb, 0.80f)), sz = argb(alpha, shade(rgb, 0.65f));
        quad(vc, m, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, top);
        quad(vc, m, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, bot);
        quad(vc, m, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, sx);
        quad(vc, m, x0, y0, z0, x0, y1, z0, x0, y1, z1, x0, y0, z1, sx);
        quad(vc, m, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, sz);
        quad(vc, m, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, sz);
    }

    /** flat disc lying on the XZ plane (puddles, rings) */
    static void flatDisc(VertexConsumer vc, Matrix4f m, float cx, float y, float cz, float rIn, float rOut, int n, int cIn, int cOut) {
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            v(vc, m, cx + c0 * rIn, y, cz + s0 * rIn, cIn); v(vc, m, cx + c0 * rOut, y, cz + s0 * rOut, cOut);
            v(vc, m, cx + c1 * rOut, y, cz + s1 * rOut, cOut); v(vc, m, cx + c1 * rIn, y, cz + s1 * rIn, cIn);
            v(vc, m, cx + c1 * rIn, y, cz + s1 * rIn, cIn); v(vc, m, cx + c1 * rOut, y, cz + s1 * rOut, cOut);
            v(vc, m, cx + c0 * rOut, y, cz + s0 * rOut, cOut); v(vc, m, cx + c0 * rIn, y, cz + s0 * rIn, cIn);
        }
    }

    /** camera facing soft disc (sparkles, muzzle flash) */
    static void glow(VertexConsumer vc, Matrix4f m, float x, float y, float z, Vector3f r, Vector3f u, float rad, int n, int cIn, int cOut) {
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            float x0 = x + (r.x * c0 + u.x * s0) * rad, y0 = y + (r.y * c0 + u.y * s0) * rad, z0 = z + (r.z * c0 + u.z * s0) * rad;
            float x1 = x + (r.x * c1 + u.x * s1) * rad, y1 = y + (r.y * c1 + u.y * s1) * rad, z1 = z + (r.z * c1 + u.z * s1) * rad;
            v(vc, m, x, y, z, cIn); v(vc, m, x0, y0, z0, cOut); v(vc, m, x1, y1, z1, cOut); v(vc, m, x1, y1, z1, cOut);
        }
    }
}
