package kz.alih.visuals.games;

/** Small camera offsets used by the games (look at the gun, shake, fall onto the table). Applied in CameraMixin. */
public final class GameCamera {
    private GameCamera() {}
    public static float yaw, pitch, roll;          // degrees added to the view
    public static double dx, dy, dz;               // metres added to the camera position
    public static float fovMul = 1f;               // 0.8 = zoom in a bit
    public static boolean active;

    public static void reset() { yaw = pitch = roll = 0f; dx = dy = dz = 0.0; fovMul = 1f; active = false; }
}
