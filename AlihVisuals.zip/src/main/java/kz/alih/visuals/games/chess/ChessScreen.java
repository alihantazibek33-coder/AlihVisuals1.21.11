package kz.alih.visuals.games.chess;

import net.minecraft.client.gui.Click;
import net.minecraft.client.input.KeyInput;

import kz.alih.visuals.Gfx;
import kz.alih.visuals.games.GUi;
import kz.alih.visuals.games.GameHub;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ChessScreen extends Screen {
    private static final int LIGHT = 0xFFE8D8B0, DARK = 0xFF8A6A48;
    private final ChessGame game;
    private int bx, by, sq, px, py, pw, ph;
    private int selected = -1;
    private List<ChessEngine.Move> targets = new ArrayList<>();
    private int promoFrom = -1, promoTo = -1;

    public ChessScreen(ChessGame game) { super(Text.literal("Chess")); this.game = game; }

    @Override public boolean shouldPause() { return false; }
    @Override public void close() { client.setScreen(null); }   // the game keeps running, reopen it from Ойындар / .game
    @Override public void renderBackground(DrawContext c, int mx, int my, float delta) { c.fill(0, 0, width, height, 0xC0090B10); }

    private void layout() {
        int side = Math.min(height - 24, width - 190);
        sq = Math.max(16, side / 8);
        int board = sq * 8;
        pw = board + 20 + 150; ph = board + 20;
        px = (width - pw) / 2; py = (height - ph) / 2;
        bx = px + 10; by = py + 10;
    }

    /** board square -> screen: white sees rank 1 at the bottom, black sees it flipped */
    private int sx(int file) { return bx + (game.myWhite ? file : 7 - file) * sq; }
    private int sy(int rank) { return by + (game.myWhite ? 7 - rank : rank) * sq; }

    private static String glyph(char p) {
        return switch (Character.toLowerCase(p)) {
            case 'k' -> "♚"; case 'q' -> "♛"; case 'r' -> "♜"; case 'b' -> "♝"; case 'n' -> "♞"; default -> "♟";
        };
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        layout();
        GUi.panel(c, px, py, pw, ph);
        ChessEngine e = game.engine;
        boolean check = e.inCheck(e.whiteToMove);
        int kingSq = -1;
        if (check) for (int i = 0; i < 64; i++) if (e.b[i] == (e.whiteToMove ? 'K' : 'k')) kingSq = i;

        for (int r = 0; r < 8; r++) for (int f = 0; f < 8; f++) {
            int s = r * 8 + f, x = sx(f), y = sy(r);
            int col = ((r + f) & 1) == 0 ? DARK : LIGHT;
            c.fill(x, y, x + sq, y + sq, col);
            if (s == e.lastFrom || s == e.lastTo) c.fill(x, y, x + sq, y + sq, 0x6628B8E8);
            if (s == selected) c.fill(x, y, x + sq, y + sq, 0x8856E07A);
            if (s == kingSq) c.fill(x, y, x + sq, y + sq, 0x88E04040);
            char p = e.b[s];
            if (p != '.') {
                float k = sq / 12.5f;
                int shade = ChessEngine.isWhite(p) ? 0xFFFFFFFF : 0xFF15171C;
                int outline = ChessEngine.isWhite(p) ? 0xFF15171C : 0xFFE0E0E0;
                float cx = x + sq / 2f, ty = y + sq / 2f - 4.5f * k;
                for (int[] o : new int[][]{{-1, 0}, {1, 0}, {0, -1}, {0, 1}}) GUi.bigText(c, textRenderer, glyph(p), cx + o[0] * k * 0.6f, ty + o[1] * k * 0.6f, k, outline);
                GUi.bigText(c, textRenderer, glyph(p), cx, ty, k, shade);
            }
            if (f == (game.myWhite ? 0 : 7) && true) c.drawTextWithShadow(textRenderer, String.valueOf(r + 1), x + 2, y + 2, col == DARK ? LIGHT : DARK);
            if (r == (game.myWhite ? 0 : 7)) c.drawTextWithShadow(textRenderer, String.valueOf((char) ('a' + f)), x + sq - 7, y + sq - 10, col == DARK ? LIGHT : DARK);
        }
        for (ChessEngine.Move m : targets) {
            int x = sx(m.to() & 7), y = sy(m.to() >> 3);
            Gfx.circle(c, x + sq / 2f, y + sq / 2f, sq * (e.b[m.to()] == '.' ? 0.14f : 0.40f), e.b[m.to()] == '.' ? 0x8856E07A : 0x66E04040);
        }

        // side panel
        int rx = bx + sq * 8 + 12, rw = 150 - 10;
        c.drawTextWithShadow(textRenderer, "Қарсылас", rx, by, 0xFF8A90A0);
        c.drawTextWithShadow(textRenderer, game.opponent(), rx, by + 11, GUi.CYAN);
        c.drawTextWithShadow(textRenderer, game.opponent() + (game.myWhite ? ": қара" : ": ақ"), rx, by + 26, 0xFFB8BFCC);
        c.drawTextWithShadow(textRenderer, "Сен: " + (game.myWhite ? "ақ" : "қара"), rx, by + 38, 0xFFB8BFCC);

        String line = game.result.isEmpty() ? (game.myTurn() ? "Сенің жүрісің" : "Қарсылас ойлануда...") : game.result;
        int ly = by + 60;
        for (var s : textRenderer.wrapLines(Text.literal(line), rw)) { c.drawTextWithShadow(textRenderer, s, rx, ly, game.result.isEmpty() ? (game.myTurn() ? 0xFF56E07A : 0xFFFFC66B) : 0xFFFFFFFF); ly += 11; }
        if (game.result.isEmpty() && check) c.drawTextWithShadow(textRenderer, "Шах!", rx, ly + 2, 0xFFFF6B6B);

        int bY = by + sq * 8 - 20;
        if (game.result.isEmpty()) {
            GUi.button(c, textRenderer, "Беріліп кету", rx, bY - 24, rw, 18, GUi.in(mx, my, rx, bY - 24, rw, 18), false);
        } else {
            String t = game.iWantRematch ? "Реванш күтілуде..." : (game.oppWantsRematch ? "Реванш қабылдау" : "Реванш");
            GUi.button(c, textRenderer, t, rx, bY - 24, rw, 18, GUi.in(mx, my, rx, bY - 24, rw, 18), game.oppWantsRematch && !game.iWantRematch);
        }
        GUi.button(c, textRenderer, "Шығу", rx, bY, rw, 18, GUi.in(mx, my, rx, bY, rw, 18), false);

        // promotion chooser
        if (promoFrom >= 0) {
            int w = sq * 4 + 8, x = (width - w) / 2, y = (height - sq - 8) / 2;
            GUi.panel(c, x, y, w, sq + 8);
            String order = "qrbn";
            for (int i = 0; i < 4; i++) {
                int cx = x + 4 + i * sq;
                boolean h = GUi.in(mx, my, cx, y + 4, sq, sq);
                c.fill(cx, y + 4, cx + sq, y + 4 + sq, h ? 0xFF56E07A : LIGHT);
                char pc = game.myWhite ? Character.toUpperCase(order.charAt(i)) : order.charAt(i);
                float k = sq / 12.5f;
                GUi.bigText(c, textRenderer, glyph(pc), cx + sq / 2f, y + 4 + sq / 2f - 4.5f * k, k, game.myWhite ? 0xFFFFFFFF : 0xFF15171C);
            }
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y(); int button = click.button();
        if (button != 0) return super.mouseClicked(click, doubled);
        layout();
        int rx = bx + sq * 8 + 12, rw = 140, bY = by + sq * 8 - 20;

        if (promoFrom >= 0) {
            int w = sq * 4 + 8, x = (width - w) / 2, y = (height - sq - 8) / 2;
            for (int i = 0; i < 4; i++)
                if (GUi.in(mx, my, x + 4 + i * sq, y + 4, sq, sq)) {
                    game.play(promoFrom, promoTo, "qrbn".charAt(i));
                    promoFrom = promoTo = -1; selected = -1; targets = new ArrayList<>();
                    return true;
                }
            promoFrom = promoTo = -1;
            return true;
        }
        if (GUi.in(mx, my, rx, bY, rw, 18)) { GameHub.closeActive(true); client.setScreen(new kz.alih.visuals.games.GamesScreen()); return true; }
        if (GUi.in(mx, my, rx, bY - 24, rw, 18)) {
            if (game.result.isEmpty()) game.resign(); else if (!game.iWantRematch) game.askRematch();
            selected = -1; targets = new ArrayList<>();
            return true;
        }
        for (int r = 0; r < 8; r++) for (int f = 0; f < 8; f++) {
            if (!GUi.in(mx, my, sx(f), sy(r), sq, sq)) continue;
            int s = r * 8 + f;
            if (selected >= 0) {
                for (ChessEngine.Move m : targets) if (m.to() == s) {
                    if (game.engine.needsPromotion(selected, s)) { promoFrom = selected; promoTo = s; return true; }
                    game.play(selected, s, '\0');
                    selected = -1; targets = new ArrayList<>();
                    return true;
                }
            }
            char p = game.engine.b[s];
            if (game.myTurn() && p != '.' && ChessEngine.isWhite(p) == game.myWhite) { selected = s; targets = game.engine.legalFrom(s); }
            else { selected = -1; targets = new ArrayList<>(); }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }
}
