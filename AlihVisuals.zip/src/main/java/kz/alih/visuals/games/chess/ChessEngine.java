package kz.alih.visuals.games.chess;

import java.util.ArrayList;
import java.util.List;

/** Full chess rules: castling, en passant, promotion, check / checkmate / stalemate, dead position (simple cases). */
public final class ChessEngine {
    public enum Status { PLAY, CHECKMATE, STALEMATE, DRAW }

    public record Move(int from, int to, char promo) {}

    /** index = rank * 8 + file, rank 0 is white's first rank. Upper case = white. '.' = empty. */
    public final char[] b = new char[64];
    public boolean whiteToMove = true;
    public boolean cwK = true, cwQ = true, cbK = true, cbQ = true;
    public int ep = -1;
    public int lastFrom = -1, lastTo = -1;

    public ChessEngine() {
        String back = "RNBQKBNR";
        for (int i = 0; i < 64; i++) b[i] = '.';
        for (int f = 0; f < 8; f++) {
            b[f] = back.charAt(f); b[8 + f] = 'P';
            b[48 + f] = 'p'; b[56 + f] = Character.toLowerCase(back.charAt(f));
        }
    }

    private ChessEngine(ChessEngine o) {
        System.arraycopy(o.b, 0, b, 0, 64);
        whiteToMove = o.whiteToMove; cwK = o.cwK; cwQ = o.cwQ; cbK = o.cbK; cbQ = o.cbQ; ep = o.ep;
    }

    public static boolean isWhite(char p) { return p >= 'A' && p <= 'Z'; }
    public static boolean isBlack(char p) { return p >= 'a' && p <= 'z'; }
    private static boolean on(int f, int r) { return f >= 0 && f < 8 && r >= 0 && r < 8; }

    // ------------------------------------------------------------------ attacks
    public boolean attacked(int sq, boolean byWhite) {
        int f = sq & 7, r = sq >> 3;
        int pr = byWhite ? r - 1 : r + 1;
        for (int df = -1; df <= 1; df += 2)
            if (on(f + df, pr) && b[pr * 8 + f + df] == (byWhite ? 'P' : 'p')) return true;
        int[][] kn = {{1, 2}, {2, 1}, {-1, 2}, {-2, 1}, {1, -2}, {2, -1}, {-1, -2}, {-2, -1}};
        for (int[] d : kn)
            if (on(f + d[0], r + d[1]) && b[(r + d[1]) * 8 + f + d[0]] == (byWhite ? 'N' : 'n')) return true;
        for (int df = -1; df <= 1; df++) for (int dr = -1; dr <= 1; dr++)
            if ((df != 0 || dr != 0) && on(f + df, r + dr) && b[(r + dr) * 8 + f + df] == (byWhite ? 'K' : 'k')) return true;
        int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
        for (int i = 0; i < 8; i++) {
            boolean diag = i >= 4;
            int x = f + dirs[i][0], y = r + dirs[i][1];
            while (on(x, y)) {
                char p = b[y * 8 + x];
                if (p != '.') {
                    if (isWhite(p) == byWhite) {
                        char u = Character.toUpperCase(p);
                        if (u == 'Q' || (diag ? u == 'B' : u == 'R')) return true;
                    }
                    break;
                }
                x += dirs[i][0]; y += dirs[i][1];
            }
        }
        return false;
    }

    private int kingSq(boolean white) {
        char k = white ? 'K' : 'k';
        for (int i = 0; i < 64; i++) if (b[i] == k) return i;
        return -1;
    }

    public boolean inCheck(boolean white) {
        int k = kingSq(white);
        return k >= 0 && attacked(k, !white);
    }

    // ------------------------------------------------------------------ move generation
    private void pseudo(int sq, List<Move> out) {
        char p = b[sq];
        if (p == '.') return;
        boolean white = isWhite(p);
        int f = sq & 7, r = sq >> 3;
        char u = Character.toUpperCase(p);
        switch (u) {
            case 'P' -> {
                int dir = white ? 1 : -1, start = white ? 1 : 6, last = white ? 7 : 0;
                int nr = r + dir;
                if (on(f, nr) && b[nr * 8 + f] == '.') {
                    addPawn(out, sq, nr * 8 + f, nr == last);
                    if (r == start && b[(r + 2 * dir) * 8 + f] == '.') out.add(new Move(sq, (r + 2 * dir) * 8 + f, '\0'));
                }
                for (int df = -1; df <= 1; df += 2) {
                    if (!on(f + df, nr)) continue;
                    int to = nr * 8 + f + df;
                    char t = b[to];
                    if ((t != '.' && isWhite(t) != white) || to == ep) addPawn(out, sq, to, nr == last);
                }
            }
            case 'N' -> {
                int[][] kn = {{1, 2}, {2, 1}, {-1, 2}, {-2, 1}, {1, -2}, {2, -1}, {-1, -2}, {-2, -1}};
                for (int[] d : kn) step(out, sq, white, f + d[0], r + d[1]);
            }
            case 'K' -> {
                for (int df = -1; df <= 1; df++) for (int dr = -1; dr <= 1; dr++)
                    if (df != 0 || dr != 0) step(out, sq, white, f + df, r + dr);
                castle(out, sq, white);
            }
            default -> {
                int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
                for (int i = 0; i < 8; i++) {
                    boolean diag = i >= 4;
                    if (u == 'R' && diag) continue;
                    if (u == 'B' && !diag) continue;
                    int x = f + dirs[i][0], y = r + dirs[i][1];
                    while (on(x, y)) {
                        char t = b[y * 8 + x];
                        if (t == '.') out.add(new Move(sq, y * 8 + x, '\0'));
                        else { if (isWhite(t) != white) out.add(new Move(sq, y * 8 + x, '\0')); break; }
                        x += dirs[i][0]; y += dirs[i][1];
                    }
                }
            }
        }
    }

    private void step(List<Move> out, int from, boolean white, int x, int y) {
        if (!on(x, y)) return;
        char t = b[y * 8 + x];
        if (t == '.' || isWhite(t) != white) out.add(new Move(from, y * 8 + x, '\0'));
    }

    private void addPawn(List<Move> out, int from, int to, boolean promote) {
        if (promote) for (char c : "qrbn".toCharArray()) out.add(new Move(from, to, c));
        else out.add(new Move(from, to, '\0'));
    }

    private void castle(List<Move> out, int sq, boolean white) {
        int home = white ? 4 : 60;
        if (sq != home || inCheck(white)) return;
        char rook = white ? 'R' : 'r';
        boolean ks = white ? cwK : cbK, qs = white ? cwQ : cbQ;
        if (ks && b[home + 1] == '.' && b[home + 2] == '.' && b[home + 3] == rook
                && !attacked(home + 1, !white) && !attacked(home + 2, !white)) out.add(new Move(home, home + 2, '\0'));
        if (qs && b[home - 1] == '.' && b[home - 2] == '.' && b[home - 3] == '.' && b[home - 4] == rook
                && !attacked(home - 1, !white) && !attacked(home - 2, !white)) out.add(new Move(home, home - 2, '\0'));
    }

    /** all legal moves of the side to move */
    public List<Move> legalMoves() {
        List<Move> res = new ArrayList<>();
        for (int sq = 0; sq < 64; sq++) {
            char p = b[sq];
            if (p == '.' || isWhite(p) != whiteToMove) continue;
            res.addAll(legalFrom(sq));
        }
        return res;
    }

    public List<Move> legalFrom(int sq) {
        List<Move> ps = new ArrayList<>(), res = new ArrayList<>();
        char p = b[sq];
        if (p == '.' || isWhite(p) != whiteToMove) return res;
        pseudo(sq, ps);
        for (Move m : ps) {
            ChessEngine c = new ChessEngine(this);
            c.apply(m);
            if (!c.inCheck(!c.whiteToMove)) res.add(m);   // the side that just moved must not be in check
        }
        return res;
    }

    public Move find(int from, int to, char promo) {
        for (Move m : legalFrom(from)) if (m.to == to && (m.promo == '\0' || m.promo == promo)) return m;
        return null;
    }

    public boolean needsPromotion(int from, int to) {
        char p = b[from];
        return (p == 'P' && (to >> 3) == 7) || (p == 'p' && (to >> 3) == 0);
    }

    // ------------------------------------------------------------------ playing a move
    public void apply(Move m) {
        char p = b[m.from];
        boolean white = isWhite(p);
        char u = Character.toUpperCase(p);
        char captured = b[m.to];
        int newEp = -1;

        if (u == 'P' && m.to == ep && captured == '.') b[(m.from >> 3) * 8 + (m.to & 7)] = '.';       // en passant
        if (u == 'P' && Math.abs((m.to >> 3) - (m.from >> 3)) == 2) newEp = (m.from + m.to) / 2;
        if (u == 'K' && Math.abs((m.to & 7) - (m.from & 7)) == 2) {                                    // castling: move the rook
            boolean king = (m.to & 7) == 6;
            int rf = (m.from & ~7) + (king ? 7 : 0), rt = (m.from & ~7) + (king ? 5 : 3);
            b[rt] = b[rf]; b[rf] = '.';
        }
        b[m.to] = m.promo != '\0' ? (white ? Character.toUpperCase(m.promo) : m.promo) : p;
        b[m.from] = '.';

        if (u == 'K') { if (white) { cwK = cwQ = false; } else { cbK = cbQ = false; } }
        if (m.from == 0 || m.to == 0) cwQ = false;
        if (m.from == 7 || m.to == 7) cwK = false;
        if (m.from == 56 || m.to == 56) cbQ = false;
        if (m.from == 63 || m.to == 63) cbK = false;

        ep = newEp;
        whiteToMove = !whiteToMove;
        lastFrom = m.from; lastTo = m.to;
    }

    // ------------------------------------------------------------------ result
    public Status status() {
        if (legalMoves().isEmpty()) return inCheck(whiteToMove) ? Status.CHECKMATE : Status.STALEMATE;
        int minors = 0, others = 0;
        for (char p : b) {
            char u = Character.toUpperCase(p);
            if (u == 'N' || u == 'B') minors++;
            else if (u == 'P' || u == 'R' || u == 'Q') others++;
        }
        if (others == 0 && minors <= 1) return Status.DRAW;
        return Status.PLAY;
    }

    public static String name(int sq) { return "" + (char) ('a' + (sq & 7)) + (char) ('1' + (sq >> 3)); }
    public static int sq(String s) { return (s.charAt(1) - '1') * 8 + (s.charAt(0) - 'a'); }
}
