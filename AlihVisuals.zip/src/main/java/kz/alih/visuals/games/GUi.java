package kz.alih.visuals.games;

import kz.alih.visuals.Gfx;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;

/** tiny drawing helpers shared by the game screens (same look as the other AlihVisuals screens) */
public final class GUi {
    private GUi() {}
    public static final int CYAN = 0xFF5CE1FF;

    public static boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    public static void button(DrawContext c, TextRenderer tr, String label, int x, int y, int w, int h, boolean hover, boolean accent) {
        Gfx.rrect(c, x, y, w, h, 7, accent ? (hover ? 0xFF6FD4F8 : 0xFF4FC3F7) : (hover ? 0xFF343946 : 0xFF2A2E38));
        c.drawCenteredTextWithShadow(tr, label, x + w / 2, y + (h - 8) / 2, accent ? 0xFF0E1218 : 0xFFB8BFCC);
    }

    public static void panel(DrawContext c, int x, int y, int w, int h) {
        Gfx.rrect(c, x - 1, y - 1, w + 2, h + 2, 11, 0xFF2C313C);
        Gfx.rrect(c, x, y, w, h, 10, 0xF01A1D24);
    }

    /** text scaled by k, centred on cx */
    public static void bigText(DrawContext c, TextRenderer tr, String s, float cx, float y, float k, int color) {
        org.joml.Matrix3x2fStack ms = c.getMatrices();
        ms.pushMatrix();
        ms.translate((float) (cx), (float) (y));
        ms.scale((float) (k), (float) (k));
        c.drawCenteredTextWithShadow(tr, s, 0, 0, color);
        ms.popMatrix();
    }
}
