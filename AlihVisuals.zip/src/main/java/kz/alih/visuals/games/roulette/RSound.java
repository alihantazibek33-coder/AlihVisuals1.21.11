package kz.alih.visuals.games.roulette;

import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

/**
 * Sounds of the roulette. They are vanilla sounds for now (no files to download); to use real recordings later add
 * your own .ogg files + sounds.json and swap the events here.
 */
final class RSound {
    private RSound() {}

    static void at(double x, double y, double z, SoundEvent e, float vol, float pitch) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world != null) mc.world.playSoundClient(x, y, z, e, SoundCategory.PLAYERS, vol, pitch, false);
    }
    static void at(double x, double y, double z, RegistryEntry<SoundEvent> e, float vol, float pitch) { at(x, y, z, e.value(), vol, pitch); }

    static void pickUp(double x, double y, double z)   { at(x, y, z, SoundEvents.BLOCK_CHAIN_PLACE, 1.0f, 0.9f); }
    static void putDown(double x, double y, double z)  { at(x, y, z, SoundEvents.BLOCK_WOOD_PLACE, 1.0f, 0.8f); }
    static void open(double x, double y, double z)     { at(x, y, z, SoundEvents.BLOCK_IRON_TRAPDOOR_OPEN, 0.7f, 1.7f); }
    static void insert(double x, double y, double z)   { at(x, y, z, SoundEvents.ITEM_CROSSBOW_LOADING_END, 1.0f, 1.3f); }
    static void close(double x, double y, double z)    { at(x, y, z, SoundEvents.BLOCK_IRON_TRAPDOOR_CLOSE, 0.8f, 1.9f); }
    static void ratchet(double x, double y, double z, float pitch) { at(x, y, z, SoundEvents.BLOCK_COMPARATOR_CLICK, 0.6f, pitch); }
    static void cock(double x, double y, double z)     { at(x, y, z, SoundEvents.BLOCK_LEVER_CLICK, 1.0f, 1.2f); }
    static void dryClick(double x, double y, double z) { at(x, y, z, SoundEvents.BLOCK_LEVER_CLICK, 1.0f, 2.0f); }
    static void heartbeat(double x, double y, double z){ at(x, y, z, SoundEvents.ENTITY_WARDEN_HEARTBEAT, 1.0f, 1.0f); }
    static void shot(double x, double y, double z) {
        at(x, y, z, SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, 2.0f, 0.55f);
        at(x, y, z, SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, 0.9f, 1.9f);
    }
    static void hurt(double x, double y, double z)     { at(x, y, z, SoundEvents.ENTITY_PLAYER_HURT, 1.0f, 0.8f); }
    static void bodyFall(double x, double y, double z) { at(x, y, z, SoundEvents.ENTITY_PLAYER_BIG_FALL, 1.0f, 0.8f); }
    static void tableAppear(double x, double y, double z) { at(x, y, z, SoundEvents.BLOCK_BEACON_ACTIVATE, 0.8f, 1.6f); }
}
