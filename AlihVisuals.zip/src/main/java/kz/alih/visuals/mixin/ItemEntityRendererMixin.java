package kz.alih.visuals.mixin;

import kz.alih.visuals.ItemPhysics;
import kz.alih.visuals.Modules;
import kz.alih.visuals.PhysicsHolder;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemEntityRenderer.class)
public abstract class ItemEntityRendererMixin {

    @Inject(method = "updateRenderState(Lnet/minecraft/entity/ItemEntity;Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;F)V",
            at = @At("RETURN"), require = 0)
    private void alih$update(ItemEntity entity, ItemEntityRenderState state, float td, CallbackInfo ci) {
        if (!Modules.ITEMPHYSIC.enabled) return;
        float[] d = ItemPhysics.data(entity, entity.isOnGround());
        float angle = (entity.getItemAge() + td) * 28f;
        float yaw = entity.uniqueOffset * 57.29578f;
        ((PhysicsHolder) (Object) state).alih$set(d[0], angle, yaw);
    }
}
