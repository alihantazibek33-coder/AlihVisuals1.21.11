package kz.alih.visuals.mixin;

import kz.alih.visuals.Modules;
import net.minecraft.client.render.fog.FogRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** NoFluid: pretend the camera is never inside water / lava so no fluid fog is applied */
@Mixin(FogRenderer.class)
public abstract class FogRendererMixin {
    @SuppressWarnings({"unchecked", "rawtypes"})
    @Inject(method = "getCameraSubmersionType", at = @At("RETURN"), cancellable = true, require = 0)
    private void alih$noFluid(CallbackInfoReturnable cir) {
        if (!Modules.NOFLUID.enabled) return;
        Object r = cir.getReturnValue();
        if (!(r instanceof Enum<?> e)) return;
        String n = e.name();
        if (n.equals("WATER") || n.equals("LAVA")) {
            cir.setReturnValue(Enum.valueOf((Class) e.getDeclaringClass(), "NONE"));
        }
    }
}
