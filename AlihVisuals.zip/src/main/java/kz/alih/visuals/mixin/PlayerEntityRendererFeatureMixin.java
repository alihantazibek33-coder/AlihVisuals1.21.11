package kz.alih.visuals.mixin;

import kz.alih.visuals.cosmetics.CosmeticsFeature;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** attaches the cosmetics feature (hat / wings / pet / body) to every player renderer */
@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererFeatureMixin
        extends LivingEntityRenderer<AbstractClientPlayerEntity, PlayerEntityRenderState, PlayerEntityModel> {

    protected PlayerEntityRendererFeatureMixin(EntityRendererFactory.Context ctx, PlayerEntityModel model, float shadow) {
        super(ctx, model, shadow);
    }

    @Inject(method = "<init>", at = @At("RETURN"), require = 0)
    private void alih$addFeature(EntityRendererFactory.Context ctx, boolean slim, CallbackInfo ci) {
        this.addFeature(new CosmeticsFeature((PlayerEntityRenderer) (Object) this));
    }
}
