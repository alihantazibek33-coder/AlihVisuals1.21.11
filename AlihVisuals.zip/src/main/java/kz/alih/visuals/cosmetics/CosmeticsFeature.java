package kz.alih.visuals.cosmetics;

/** TODO(1.21.11): hat / wings / pet rendering needs porting to the new OrderedRenderCommandQueue feature-renderer API. */
public class CosmeticsFeature {
    public static void register() { }
}
